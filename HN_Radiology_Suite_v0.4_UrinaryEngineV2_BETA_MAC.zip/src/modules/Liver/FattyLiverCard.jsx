import { fattyLiverLibrary } from "../../library/Liver/index.js";

export function getFattyLiverOutput(state) {
  if (!state.enabled) return null;

  const item = fattyLiverLibrary[state.grade];

  return {
    finding: item.finding,
    impression: item.impression,
    recommendation: item.recommendation,
  };
}

function FattyLiverCard({ value, onChange }) {
  return (
    <>
      <label>
        <input
          type="checkbox"
          checked={value.enabled}
          onChange={(e) =>
            onChange({
              ...value,
              enabled: e.target.checked,
            })
          }
        />
        استئاتوز کبد
      </label>

      {value.enabled && (
        <select
          value={value.grade}
          onChange={(e) =>
            onChange({
              ...value,
              grade: e.target.value,
            })
          }
        >
          <option value="I">Grade I</option>
          <option value="I-II">Grade I-II</option>
          <option value="II">Grade II</option>
          <option value="II-III">Grade II-III</option>
          <option value="III">Grade III</option>
        </select>
      )}
    </>
  );
}

export default FattyLiverCard;