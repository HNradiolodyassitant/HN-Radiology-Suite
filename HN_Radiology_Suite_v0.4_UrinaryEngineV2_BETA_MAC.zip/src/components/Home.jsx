function Home({ goUltrasound }) {
  const cardStyle = {
    padding: "28px 48px",
    borderRadius: "16px",
    background: "#1e293b",
    color: "white",
    border: "1px solid #334155",
    fontSize: "20px",
    minWidth: "250px",
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0f172a",
        color: "white",
        padding: "clamp(24px, 5vw, 48px)",
        textAlign: "center",
        direction: "rtl",
      }}
    >
      <h1>HN Radiology Suite</h1>
      <p>طراحی‌شده برای دکتر هاشم نشاطی</p>

      <div
        style={{
          marginTop: "48px",
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        <button
          type="button"
          onClick={goUltrasound}
          style={{ ...cardStyle, cursor: "pointer" }}
        >
          Ultrasound
          <br />
          گزارش‌های سونوگرافی
        </button>

        <button
          type="button"
          disabled
          style={{ ...cardStyle, opacity: 0.55, cursor: "not-allowed" }}
        >
          MRI
          <br />
          در نسخه‌های بعدی
        </button>
      </div>
    </div>
  );
}

export default Home;
