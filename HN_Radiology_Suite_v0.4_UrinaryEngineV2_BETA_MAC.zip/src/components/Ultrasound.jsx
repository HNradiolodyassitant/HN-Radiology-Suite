import { useMemo, useState } from "react";
import KidneyCard from "./Kidney/KidneyCard.jsx";
import LiverCard from "./Liver/LiverCard.jsx";
import ProstateCard from "./Prostate/ProstateCard.jsx";
import ReportOutput from "./Common/ReportOutput.jsx";

const emptyReport = { finding: "", impression: "", recommendation: "" };

function uniqueLines(items) {
  return [...new Set(
    items
      .flatMap((item) => (item || "").split("\n"))
      .map((item) => item.trim())
      .filter(Boolean)
  )];
}

function Ultrasound({ goBack }) {
  const [activeOrgan, setActiveOrgan] = useState("kidney");
  const [kidneyReport, setKidneyReport] = useState(emptyReport);
  const [liverReport, setLiverReport] = useState(emptyReport);
  const [prostateReport, setProstateReport] = useState(emptyReport);
  const [included, setIncluded] = useState({ liver: true, kidney: true, prostate: false });

  const reports = useMemo(
    () => ({ liver: liverReport, kidney: kidneyReport, prostate: prostateReport }),
    [kidneyReport, liverReport, prostateReport]
  );

  const combinedReport = useMemo(() => {
    const order = ["liver", "kidney", "prostate"];
    const selected = order.filter((key) => included[key]).map((key) => reports[key]);

    return {
      finding: uniqueLines(selected.map((item) => item.finding)).join("\n"),
      impression: uniqueLines(selected.map((item) => item.impression)).join("\n"),
      recommendation: uniqueLines(selected.map((item) => item.recommendation)).join("\n"),
    };
  }, [included, reports]);

  const quickBtn = (active) => ({
    padding: "10px 16px",
    margin: "4px",
    borderRadius: "8px",
    border: active ? "2px solid #38bdf8" : "1px solid #64748b",
    background: active ? "#0369a1" : "#334155",
    color: "white",
    cursor: "pointer",
  });

  const presetBtn = {
    padding: "8px 12px",
    borderRadius: "8px",
    border: "1px solid #64748b",
    background: "#334155",
    color: "white",
    cursor: "pointer",
  };

  const applyPreset = (preset) => {
    if (preset === "abdomen") setIncluded({ liver: true, kidney: true, prostate: false });
    if (preset === "maleAbdomenPelvis") setIncluded({ liver: true, kidney: true, prostate: true });
    if (preset === "urinary") setIncluded({ liver: false, kidney: true, prostate: false });
    if (preset === "liver") setIncluded({ liver: true, kidney: false, prostate: false });
  };

  const toggleIncluded = (key) => {
    setIncluded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0f172a", color: "white", direction: "rtl", padding: "clamp(16px, 4vw, 32px)" }}>
      <button type="button" onClick={goBack}>بازگشت</button>
      <h1>HN Ultrasound Report Engine</h1>
      <p style={{ color: "#cbd5e1" }}>نسخه ۰.۴ — گزارش تجمیعی با Urinary Engine v2، کیست و سنگ چندگانه، ADPKD و الگوهای پیشرفته مثانه.</p>

      <section style={{ background: "#1e293b", border: "1px solid #334155", borderRadius: "14px", padding: "16px", marginBottom: "18px" }}>
        <h2 style={{ marginTop: 0 }}>نوع گزارش نهایی</h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
          <button type="button" style={presetBtn} onClick={() => applyPreset("abdomen")}>شکم</button>
          <button type="button" style={presetBtn} onClick={() => applyPreset("maleAbdomenPelvis")}>شکم و لگن آقایان</button>
          <button type="button" style={presetBtn} onClick={() => applyPreset("urinary")}>سیستم ادراری</button>
          <button type="button" style={presetBtn} onClick={() => applyPreset("liver")}>کبد و صفرا</button>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: "18px", marginTop: "14px" }}>
          <label><input type="checkbox" checked={included.liver} onChange={() => toggleIncluded("liver")} /> کبد و سیستم صفراوی در گزارش نهایی</label>
          <label><input type="checkbox" checked={included.kidney} onChange={() => toggleIncluded("kidney")} /> کلیه، حالب و مثانه در گزارش نهایی</label>
          <label><input type="checkbox" checked={included.prostate} onChange={() => toggleIncluded("prostate")} /> پروستات و PVR در گزارش نهایی</label>
        </div>
      </section>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "4px" }}>
        <button type="button" style={quickBtn(activeOrgan === "kidney")} onClick={() => setActiveOrgan("kidney")}>کلیه، حالب و مثانه</button>
        <button type="button" style={quickBtn(activeOrgan === "liver")} onClick={() => setActiveOrgan("liver")}>کبد و سیستم صفراوی</button>
        <button type="button" style={quickBtn(activeOrgan === "prostate")} onClick={() => setActiveOrgan("prostate")}>پروستات و PVR</button>
      </div>

      {/* هر سه فرم همیشه mounted هستند تا با تعویض تب، اطلاعات واردشده پاک نشود. */}
      <div style={{ display: activeOrgan === "kidney" ? "block" : "none" }}>
        <KidneyCard onReportChange={setKidneyReport} showPreview={false} />
      </div>
      <div style={{ display: activeOrgan === "liver" ? "block" : "none" }}>
        <LiverCard onReportChange={setLiverReport} showPreview={false} />
      </div>
      <div style={{ display: activeOrgan === "prostate" ? "block" : "none" }}>
        <ProstateCard onReportChange={setProstateReport} showPreview={false} />
      </div>

      <section style={{ background: "#1e293b", border: "2px solid #38bdf8", borderRadius: "14px", padding: "18px", marginTop: "24px" }}>
        <h2 style={{ marginTop: 0 }}>گزارش نهایی بیمار</h2>
        <p style={{ color: "#cbd5e1", marginTop: 0 }}>تمام بخش‌های انتخاب‌شده در این قسمت کنار هم قرار می‌گیرند؛ فقط همین گزارش را یک‌بار کپی کنید.</p>
        <ReportOutput {...combinedReport} />
      </section>
    </div>
  );
}

export default Ultrasound;
