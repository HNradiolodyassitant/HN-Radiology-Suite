import { useEffect, useMemo, useState } from "react";
import {
  fattyLiverLibrary,
  hemangiomaLibrary,
  hepatomegalyLibrary,
  ihbdLibrary,
  liverCystLibrary,
} from "../../library/Liver/index.js";
import ReportOutput from "../Common/ReportOutput.jsx";

const initialState = {
  liverStatus: "normal",
  fattyGrade: "I",
  sizeStatus: "normal",
  ccLength: "",
  cystEnabled: false,
  cystSize: "",
  cystLocation: "لوب راست",
  hemangiomaEnabled: false,
  hemangiomaType: "smallTypical",
  hemangiomaSegment: "VII",
  hemangiomaLobe: "راست",
  hemangiomaDiameter: "",
  hemangiomaLength: "",
  hemangiomaWidth: "",
  ihbd: "none",
  gallbladderStatus: "normal",
  gallstoneSize: "",
  wallThickness: "",
  cbd: "",
};

const fieldStyle = {
  width: "100%",
  padding: "9px",
  borderRadius: "8px",
  border: "1px solid #64748b",
  marginTop: "5px",
  background: "#f8fafc",
};

const groupStyle = {
  background: "#172033",
  border: "1px solid #334155",
  borderRadius: "12px",
  padding: "14px",
  marginTop: "14px",
};

function LiverCard({ onReportChange, showPreview = true }) {
  const [state, setState] = useState(initialState);
  const set = (key, value) => setState((prev) => ({ ...prev, [key]: value }));

  const report = useMemo(() => {
    const cards = [];
    const baseFindings = [];

    const hasFocalFinding =
      (state.cystEnabled && state.cystSize) ||
      (state.hemangiomaEnabled &&
        (state.hemangiomaDiameter || (state.hemangiomaLength && state.hemangiomaWidth)));

    if (state.liverStatus === "normal") {
      const sizeText = state.sizeStatus === "normal" ? "اندازه" : "حدود";
      let normalLiver = `کبد از نظر ${sizeText} و اکوتکستچر دارای نمای طبیعی است.`;
      if (!hasFocalFinding) normalLiver += " ضایعه فوکال واضحی در پارانشیم آن مشاهده نشد.";
      baseFindings.push(normalLiver);
    } else {
      const fatty = fattyLiverLibrary[state.fattyGrade];
      cards.push(fatty);
    }

    if (state.sizeStatus === "hepatomegaly" && state.ccLength) {
      cards.push(hepatomegalyLibrary.build(state.ccLength));
    }

    if (state.cystEnabled && state.cystSize) {
      cards.push(liverCystLibrary.simple.build(state.cystSize, state.cystLocation));
    }

    if (state.hemangiomaEnabled) {
      if (state.hemangiomaType === "smallTypical" && state.hemangiomaDiameter) {
        cards.push(
          hemangiomaLibrary.smallTypical.build(
            state.hemangiomaSegment,
            state.hemangiomaLobe,
            state.hemangiomaDiameter
          )
        );
      }
      if (state.hemangiomaType === "typical" && state.hemangiomaLength && state.hemangiomaWidth) {
        cards.push(
          hemangiomaLibrary.typical.build(
            state.hemangiomaSegment,
            state.hemangiomaLobe,
            state.hemangiomaLength,
            state.hemangiomaWidth
          )
        );
      }
      if (state.hemangiomaType === "atypical" && state.hemangiomaLength && state.hemangiomaWidth) {
        cards.push(
          hemangiomaLibrary.atypical.build(
            state.hemangiomaSegment,
            state.hemangiomaLobe,
            state.hemangiomaLength,
            state.hemangiomaWidth
          )
        );
      }
    }

    if (state.ihbd !== "none") cards.push(ihbdLibrary[state.ihbd].build());

    if (state.gallbladderStatus === "normal") {
      baseFindings.push("کیسه صفرا دارای ابعاد و ضخامت جداری طبیعی بوده و فاقد سنگ است.");
    } else if (state.gallbladderStatus === "stone" && state.gallstoneSize) {
      baseFindings.push(
        `یک سنگ اکوژن به قطر ${state.gallstoneSize} میلی‌متر همراه با سایه آکوستیک خلفی در کیسه صفرا رویت شد.` +
          (state.wallThickness ? ` ضخامت جدار کیسه صفرا حدود ${state.wallThickness} میلی‌متر است.` : "")
      );
      cards.push({
        finding: "",
        impression: "Cholelithiasis.",
        recommendation: "تطابق با علائم بالینی و آزمایشگاهی از نظر کوله‌سیستیت توصیه می‌شود.",
      });
    }

    if (state.cbd) {
      baseFindings.push(`قطر مجرای صفراوی مشترک (CBD) حدود ${state.cbd} میلی‌متر اندازه‌گیری شد.`);
    } else if (state.ihbd === "none") {
      baseFindings.push("مجاری صفراوی داخل و خارج کبدی دیلاته نیستند.");
    }

    const validCards = cards.filter(Boolean);
    const findings = [...baseFindings, ...validCards.map((card) => card.finding).filter(Boolean)];
    const impressions = validCards.map((card) => card.impression).filter(Boolean);
    const recommendations = [...new Set(validCards.map((card) => card.recommendation).filter(Boolean))];

    return {
      finding: findings.join("\n"),
      impression: impressions.length ? impressions.join("\n") : "یافته پاتولوژیک بارزی در کبد و سیستم صفراوی مشاهده نشد.",
      recommendation: recommendations.join("\n"),
    };
  }, [state]);

  useEffect(() => {
    onReportChange?.(report);
  }, [onReportChange, report]);

  return (
    <div style={{ background: "#1e293b", padding: "18px", borderRadius: "14px", border: "1px solid #334155", marginTop: "18px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", alignItems: "center", flexWrap: "wrap" }}>
        <h2 style={{ margin: 0 }}>کبد و سیستم صفراوی</h2>
        <button type="button" onClick={() => setState(initialState)}>پاک‌کردن فرم</button>
      </div>

      <div style={groupStyle}>
        <h3>پارانشیم کبد</h3>
        <select style={fieldStyle} value={state.liverStatus} onChange={(e) => set("liverStatus", e.target.value)}>
          <option value="normal">طبیعی</option>
          <option value="fatty">کبد چرب</option>
        </select>
        {state.liverStatus === "fatty" && (
          <select style={fieldStyle} value={state.fattyGrade} onChange={(e) => set("fattyGrade", e.target.value)}>
            <option value="I">Grade I</option>
            <option value="I-II">Grade I-II</option>
            <option value="II">Grade II</option>
            <option value="II-III">Grade II-III</option>
            <option value="III">Grade III</option>
          </select>
        )}

        <select style={fieldStyle} value={state.sizeStatus} onChange={(e) => set("sizeStatus", e.target.value)}>
          <option value="normal">اندازه طبیعی</option>
          <option value="hepatomegaly">هپاتومگالی</option>
        </select>
        {state.sizeStatus === "hepatomegaly" && (
          <input style={fieldStyle} type="number" placeholder="CC لوب راست (mm)" value={state.ccLength} onChange={(e) => set("ccLength", e.target.value)} />
        )}
      </div>

      <div style={groupStyle}>
        <label><input type="checkbox" checked={state.cystEnabled} onChange={(e) => set("cystEnabled", e.target.checked)} /> کیست ساده کبد</label>
        {state.cystEnabled && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "10px", marginTop: "10px" }}>
            <input style={fieldStyle} type="number" placeholder="قطر (mm)" value={state.cystSize} onChange={(e) => set("cystSize", e.target.value)} />
            <input style={fieldStyle} placeholder="محل؛ مثال: لوب راست" value={state.cystLocation} onChange={(e) => set("cystLocation", e.target.value)} />
          </div>
        )}
      </div>

      <div style={groupStyle}>
        <label><input type="checkbox" checked={state.hemangiomaEnabled} onChange={(e) => set("hemangiomaEnabled", e.target.checked)} /> همانژیوم</label>
        {state.hemangiomaEnabled && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: "10px", marginTop: "10px" }}>
            <select style={fieldStyle} value={state.hemangiomaType} onChange={(e) => set("hemangiomaType", e.target.value)}>
              <option value="smallTypical">کوچک و تیپیک</option>
              <option value="typical">تیپیک</option>
              <option value="atypical">آتیپیک</option>
            </select>
            <input style={fieldStyle} placeholder="سگمان" value={state.hemangiomaSegment} onChange={(e) => set("hemangiomaSegment", e.target.value)} />
            <select style={fieldStyle} value={state.hemangiomaLobe} onChange={(e) => set("hemangiomaLobe", e.target.value)}><option>راست</option><option>چپ</option></select>
            {state.hemangiomaType === "smallTypical" ? (
              <input style={fieldStyle} type="number" placeholder="قطر (mm)" value={state.hemangiomaDiameter} onChange={(e) => set("hemangiomaDiameter", e.target.value)} />
            ) : (
              <>
                <input style={fieldStyle} type="number" placeholder="طول (mm)" value={state.hemangiomaLength} onChange={(e) => set("hemangiomaLength", e.target.value)} />
                <input style={fieldStyle} type="number" placeholder="عرض (mm)" value={state.hemangiomaWidth} onChange={(e) => set("hemangiomaWidth", e.target.value)} />
              </>
            )}
          </div>
        )}
      </div>

      <div style={groupStyle}>
        <h3>مجاری صفراوی و کیسه صفرا</h3>
        <select style={fieldStyle} value={state.ihbd} onChange={(e) => set("ihbd", e.target.value)}>
          <option value="none">IHBD طبیعی</option>
          <option value="mild">اتساع خفیف</option>
          <option value="moderate">اتساع متوسط</option>
          <option value="severe">اتساع شدید</option>
        </select>
        <select style={fieldStyle} value={state.gallbladderStatus} onChange={(e) => set("gallbladderStatus", e.target.value)}>
          <option value="normal">کیسه صفرا طبیعی</option>
          <option value="stone">سنگ کیسه صفرا</option>
        </select>
        {state.gallbladderStatus === "stone" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "10px" }}>
            <input style={fieldStyle} type="number" placeholder="قطر سنگ (mm)" value={state.gallstoneSize} onChange={(e) => set("gallstoneSize", e.target.value)} />
            <input style={fieldStyle} type="number" placeholder="ضخامت جدار (mm)" value={state.wallThickness} onChange={(e) => set("wallThickness", e.target.value)} />
          </div>
        )}
        <input style={fieldStyle} type="number" placeholder="CBD (mm؛ اختیاری)" value={state.cbd} onChange={(e) => set("cbd", e.target.value)} />
      </div>

      {showPreview && <ReportOutput {...report} />}
    </div>
  );
}

export default LiverCard;
