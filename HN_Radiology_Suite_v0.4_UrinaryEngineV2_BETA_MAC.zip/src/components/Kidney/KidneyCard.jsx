import { useEffect, useMemo, useState } from "react";
import {
  bladderLibrary,
  hydronephrosisLibrary,
  kidneyStoneLibrary,
  renalCystLibrary,
  renalEchogenicityLibrary,
  ureterStoneLibrary,
} from "../../library/Kidney/index.js";
import ReportOutput from "../Common/ReportOutput.jsx";

const makeCyst = (id = 1) => ({
  id,
  side: "راست",
  pole: "فوقانی",
  size: "",
  relation: "کورتیکال",
});

const makeStone = (id = 1) => ({
  id,
  side: "راست",
  calyx: "کالیس تحتانی",
  size: "",
  shadow: true,
  twinkle: true,
});

const makeSideCystSummary = () => ({
  enabled: false,
  count: "3",
  largestSize: "",
  pole: "فوقانی",
  relation: "کورتیکال",
});

const makeSideStoneSummary = () => ({
  enabled: false,
  largestSize: "",
  calyx: "کالیس تحتانی",
  shadow: true,
  twinkle: true,
});

const createInitialState = () => ({
  rightLength: "",
  rightParenchyma: "",
  leftLength: "",
  leftParenchyma: "",
  echogenicity: "normal",

  cystMode: "none",
  cysts: [makeCyst(1)],
  cystSummary: {
    راست: makeSideCystSummary(),
    چپ: makeSideCystSummary(),
  },
  adpkd: {
    rightLargestSize: "",
    rightPole: "فوقانی",
    leftLargestSize: "",
    leftPole: "فوقانی",
  },

  stoneMode: "none",
  stones: [makeStone(1)],
  stoneSummary: {
    راست: makeSideStoneSummary(),
    چپ: makeSideStoneSummary(),
  },
  staghorn: {
    side: "راست",
    locations: ["لگنچه"],
    size: "",
    shadow: true,
    twinkle: true,
  },

  ureterStoneEnabled: false,
  ureterSide: "راست",
  ureterLocation: "دیستال",
  ureterSize: "",
  distanceFromUPJ: "",
  distanceFromUVJ: "",
  urinaryJet: "بررسی نشد",
  hydronephrosis: "ندارد",
  pelvicAP: "",

  bladderMode: "normal",
  bladderWallThickness: "",
  bladderOptionalUA: false,
  bladderProstateRelated: false,
  bladderMucosalIrregularity: false,
  bladderDiverticulum: false,
});

const fieldStyle = {
  width: "100%",
  padding: "9px",
  borderRadius: "8px",
  border: "1px solid #64748b",
  marginTop: "5px",
  background: "#f8fafc",
};

const groupStyle = {
  background: "#172033",
  border: "1px solid #334155",
  borderRadius: "12px",
  padding: "14px",
  marginTop: "14px",
};

const subCardStyle = {
  background: "#0f172a",
  border: "1px solid #475569",
  borderRadius: "10px",
  padding: "12px",
  marginTop: "10px",
};

const gridStyle = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
  gap: "10px",
  marginTop: "10px",
};

function CystFields({ value, onChange, onRemove, showRemove }) {
  return (
    <div style={subCardStyle}>
      <div style={gridStyle}>
        <label>
          سمت
          <select style={fieldStyle} value={value.side} onChange={(e) => onChange("side", e.target.value)}>
            <option>راست</option>
            <option>چپ</option>
          </select>
        </label>
        <label>
          قطب
          <select style={fieldStyle} value={value.pole} onChange={(e) => onChange("pole", e.target.value)}>
            <option>فوقانی</option>
            <option>میانی</option>
            <option>تحتانی</option>
          </select>
        </label>
        <label>
          ارتباط
          <select style={fieldStyle} value={value.relation} onChange={(e) => onChange("relation", e.target.value)}>
            <option>کورتیکال</option>
            <option>اگزوکورتیکال</option>
            <option>اگزوفیتیک</option>
            <option>پاراپلویک</option>
          </select>
        </label>
        <label>
          قطر (mm)
          <input style={fieldStyle} type="number" value={value.size} onChange={(e) => onChange("size", e.target.value)} />
        </label>
      </div>
      {showRemove && (
        <button type="button" onClick={onRemove} style={{ marginTop: "10px" }}>
          حذف این کیست
        </button>
      )}
    </div>
  );
}

function StoneFields({ value, onChange, onRemove, showRemove }) {
  return (
    <div style={subCardStyle}>
      <div style={gridStyle}>
        <label>
          سمت
          <select style={fieldStyle} value={value.side} onChange={(e) => onChange("side", e.target.value)}>
            <option>راست</option>
            <option>چپ</option>
          </select>
        </label>
        <label>
          محل
          <select style={fieldStyle} value={value.calyx} onChange={(e) => onChange("calyx", e.target.value)}>
            <option>کالیس فوقانی</option>
            <option>کالیس میانی</option>
            <option>کالیس تحتانی</option>
            <option>لگنچه</option>
          </select>
        </label>
        <label>
          قطر (mm)
          <input style={fieldStyle} type="number" value={value.size} onChange={(e) => onChange("size", e.target.value)} />
        </label>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "18px", marginTop: "10px" }}>
        <label>
          <input type="checkbox" checked={value.shadow} onChange={(e) => onChange("shadow", e.target.checked)} /> سایه آکوستیک خلفی
        </label>
        <label>
          <input type="checkbox" checked={value.twinkle} onChange={(e) => onChange("twinkle", e.target.checked)} /> توینکل آرتیفکت
        </label>
      </div>
      {showRemove && (
        <button type="button" onClick={onRemove} style={{ marginTop: "10px" }}>
          حذف این سنگ
        </button>
      )}
    </div>
  );
}

function KidneyCard({ onReportChange, showPreview = true }) {
  const [state, setState] = useState(createInitialState);

  const set = (key, value) => setState((prev) => ({ ...prev, [key]: value }));

  const updateListItem = (key, id, field, value) => {
    setState((prev) => ({
      ...prev,
      [key]: prev[key].map((item) => (item.id === id ? { ...item, [field]: value } : item)),
    }));
  };

  const removeListItem = (key, id, factory) => {
    setState((prev) => {
      const next = prev[key].filter((item) => item.id !== id);
      return { ...prev, [key]: next.length ? next : [factory(1)] };
    });
  };

  const addListItem = (key, factory) => {
    setState((prev) => {
      const nextId = Math.max(0, ...prev[key].map((item) => item.id)) + 1;
      return { ...prev, [key]: [...prev[key], factory(nextId)] };
    });
  };

  const updateSideSummary = (key, side, field, value) => {
    setState((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        [side]: { ...prev[key][side], [field]: value },
      },
    }));
  };

  const toggleStaghornLocation = (location) => {
    setState((prev) => {
      const exists = prev.staghorn.locations.includes(location);
      const locations = exists
        ? prev.staghorn.locations.filter((item) => item !== location)
        : [...prev.staghorn.locations, location];
      return { ...prev, staghorn: { ...prev.staghorn, locations } };
    });
  };

  const validCysts = state.cysts.filter((item) => item.side && item.pole && item.size);
  const validStones = state.stones.filter((item) => item.side && item.calyx && item.size);
  const hasKidneyStone =
    (state.stoneMode === "single" && validStones.length > 0) ||
    (state.stoneMode === "multipleDetailed" && validStones.length > 0) ||
    (state.stoneMode === "multipleSummary" &&
      ["راست", "چپ"].some(
        (side) => state.stoneSummary[side].enabled && state.stoneSummary[side].largestSize
      )) ||
    (state.stoneMode === "staghorn" && state.staghorn.size && state.staghorn.locations.length > 0);
  const hasUreterStone = state.ureterStoneEnabled && Boolean(state.ureterSize);
  const hasAnyStone = Boolean(hasKidneyStone || hasUreterStone);
  const anyStoneDeclared = state.stoneMode !== "none" || state.ureterStoneEnabled;
  const hasHydronephrosis = state.hydronephrosis !== "ندارد";

  const report = useMemo(() => {
    const cards = [];

    if (state.cystMode === "adpkd") {
      cards.push(
        renalCystLibrary.adpkd.build({
          rightLength: state.rightLength,
          leftLength: state.leftLength,
          rightLargestSize: state.adpkd.rightLargestSize,
          rightPole: state.adpkd.rightPole,
          leftLargestSize: state.adpkd.leftLargestSize,
          leftPole: state.adpkd.leftPole,
          noStoneOrHydronephrosis: !anyStoneDeclared && !hasHydronephrosis,
        })
      );
    } else {
      const dimensions = [];
      if (state.rightLength || state.rightParenchyma) {
        dimensions.push(
          `کلیه راست به طول ${state.rightLength || "…"} میلی‌متر و ضخامت پارانشیم ${state.rightParenchyma || "…"} میلی‌متر`
        );
      }
      if (state.leftLength || state.leftParenchyma) {
        dimensions.push(
          `کلیه چپ به طول ${state.leftLength || "…"} میلی‌متر و ضخامت پارانشیم ${state.leftParenchyma || "…"} میلی‌متر`
        );
      }

      const baseFinding = dimensions.length
        ? `${dimensions.join(" و ")} اندازه‌گیری شدند.`
        : "کلیه‌ها از نظر اندازه و ضخامت پارانشیم در محدوده طبیعی هستند.";
      const echoCard = renalEchogenicityLibrary[state.echogenicity].build();
      cards.push({
        finding: `${baseFinding} ${echoCard.finding}`,
        impression: state.echogenicity === "normal" ? "" : echoCard.impression,
        recommendation: state.echogenicity === "normal" ? "" : echoCard.recommendation,
      });
    }

    if (state.cystMode === "single") {
      cards.push(renalCystLibrary.single.build(state.cysts[0]));
    }
    if (state.cystMode === "multipleDetailed") {
      cards.push(renalCystLibrary.multipleDetailed.build(state.cysts));
    }
    if (state.cystMode === "multipleSummary") {
      cards.push(renalCystLibrary.multipleSummary.build(state.cystSummary));
    }

    if (state.stoneMode === "single") {
      cards.push(kidneyStoneLibrary.single.build(state.stones[0]));
    }
    if (state.stoneMode === "multipleDetailed") {
      cards.push(kidneyStoneLibrary.multipleDetailed.build(state.stones));
    }
    if (state.stoneMode === "multipleSummary") {
      cards.push(kidneyStoneLibrary.multipleSummary.build(state.stoneSummary));
    }
    if (state.stoneMode === "staghorn") {
      cards.push(kidneyStoneLibrary.staghorn.build(state.staghorn));
    }

    if (hasUreterStone) {
      cards.push(
        ureterStoneLibrary.build({
          side: state.ureterSide,
          location: state.ureterLocation,
          size: state.ureterSize,
          distanceFromUPJ: state.distanceFromUPJ,
          distanceFromUVJ: state.distanceFromUVJ,
          hydronephrosis: state.hydronephrosis,
          pelvicAP: state.pelvicAP,
          urinaryJet: state.urinaryJet,
        })
      );
    } else if (hasHydronephrosis) {
      cards.push(
        hydronephrosisLibrary.build({
          side: state.ureterSide,
          grade: state.hydronephrosis,
          pelvicAP: state.pelvicAP,
        })
      );
    }

    cards.push(
      bladderLibrary.build({
        mode: state.bladderMode,
        wallThickness: state.bladderWallThickness,
        optionalUA: state.bladderOptionalUA,
        prostateRelated: state.bladderProstateRelated,
        mucosalIrregularity: state.bladderMucosalIrregularity,
        diverticulum: state.bladderDiverticulum,
        hasUrinaryStone: hasAnyStone,
      })
    );

    let normalTail = "";
    if (state.cystMode !== "adpkd") {
      if (!anyStoneDeclared && !hasHydronephrosis) {
        normalTail = "شواهدی از سنگ یا هیدرونفروز در دو سمت مشاهده نشد.";
      } else if (!anyStoneDeclared) {
        normalTail = "سنگ کلیوی یا حالبی مشخصی مشاهده نشد.";
      } else if (!hasHydronephrosis) {
        normalTail = "هیدرونفروز در دو سمت مشاهده نشد.";
      }
    }

    const validCards = cards.filter(Boolean);
    const findings = validCards.map((item) => item.finding).filter(Boolean);
    if (normalTail) findings.push(normalTail);

    const impressions = [...new Set(validCards.map((item) => item.impression).filter(Boolean))];
    const recommendations = [
      ...new Set(validCards.map((item) => item.recommendation).filter(Boolean)),
    ];

    return {
      finding: findings.join("\n"),
      impression: impressions.length
        ? impressions.join("\n")
        : "یافته پاتولوژیک بارزی در سیستم ادراری مشاهده نشد.",
      recommendation: recommendations.join("\n"),
    };
  }, [state, hasAnyStone, anyStoneDeclared, hasHydronephrosis, hasUreterStone]);

  const warnings = useMemo(() => {
    const items = [];
    if (state.cystMode === "single" && !state.cysts[0]?.size) items.push("قطر کیست منفرد وارد نشده است.");
    if (state.cystMode === "multipleDetailed" && validCysts.length < 2) items.push("برای حالت چند کیست مشخص، حداقل دو کیست کامل وارد کنید.");
    if (
      state.cystMode === "multipleSummary" &&
      !["راست", "چپ"].some(
        (side) => state.cystSummary[side].enabled && state.cystSummary[side].largestSize
      )
    ) {
      items.push("در حالت کیست‌های متعدد، حداقل یک کلیه و اندازه بزرگ‌ترین کیست را ثبت کنید.");
    }
    if (
      state.cystMode === "adpkd" &&
      (!state.rightLength ||
        !state.leftLength ||
        !state.adpkd.rightLargestSize ||
        !state.adpkd.leftLargestSize)
    ) {
      items.push("برای قالب ADPKD، طول هر دو کلیه و اندازه بزرگ‌ترین کیست هر سمت را کامل کنید.");
    }
    if (state.stoneMode === "single" && !state.stones[0]?.size) items.push("قطر سنگ منفرد وارد نشده است.");
    if (state.stoneMode === "multipleDetailed" && validStones.length < 2) items.push("برای حالت چند سنگ مشخص، حداقل دو سنگ کامل وارد کنید.");
    if (
      state.stoneMode === "multipleSummary" &&
      !["راست", "چپ"].some(
        (side) => state.stoneSummary[side].enabled && state.stoneSummary[side].largestSize
      )
    ) {
      items.push("در حالت سنگ‌های متعدد، حداقل یک کلیه و اندازه بزرگ‌ترین سنگ را ثبت کنید.");
    }
    if (state.stoneMode === "staghorn" && (!state.staghorn.size || !state.staghorn.locations.length)) items.push("برای سنگ شاخ‌گوزنی، محل درگیری و قطر تجمعی را ثبت کنید.");
    if (state.ureterStoneEnabled && !state.ureterSize) items.push("قطر سنگ حالب وارد نشده است.");
    if (state.bladderMode === "mildDebris" && hasAnyStone) items.push("برای دبری مثانه در بیمار دارای سنگ، بهتر است الگوی «دبری همراه با سنگ — احتمال هماچوری» انتخاب شود.");
    if (state.bladderMode === "stoneDebris" && !hasAnyStone) items.push("حالت دبری مرتبط با سنگ انتخاب شده، اما سنگ کلیه یا حالب ثبت نشده است.");
    return items;
  }, [state, validCysts.length, validStones.length, hasAnyStone]);

  useEffect(() => {
    onReportChange?.(report);
  }, [onReportChange, report]);

  return (
    <div style={{ background: "#1e293b", padding: "18px", borderRadius: "14px", border: "1px solid #334155", marginTop: "18px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", alignItems: "center", flexWrap: "wrap" }}>
        <h2 style={{ margin: 0 }}>کلیه، حالب و مثانه — Urinary Engine v2</h2>
        <button type="button" onClick={() => setState(createInitialState())}>پاک‌کردن فرم</button>
      </div>

      {warnings.length > 0 && (
        <div style={{ background: "#451a03", border: "1px solid #f59e0b", borderRadius: "10px", padding: "12px", marginTop: "14px" }}>
          <strong>موارد نیازمند تکمیل:</strong>
          <ul style={{ marginBottom: 0 }}>
            {warnings.map((item) => <li key={item}>{item}</li>)}
          </ul>
        </div>
      )}

      <div style={groupStyle}>
        <h3>ابعاد و پارانشیم کلیه‌ها</h3>
        <div style={gridStyle}>
          <label>طول کلیه راست (mm)<input style={fieldStyle} type="number" value={state.rightLength} onChange={(e) => set("rightLength", e.target.value)} /></label>
          <label>پارانشیم راست (mm)<input style={fieldStyle} type="number" value={state.rightParenchyma} onChange={(e) => set("rightParenchyma", e.target.value)} /></label>
          <label>طول کلیه چپ (mm)<input style={fieldStyle} type="number" value={state.leftLength} onChange={(e) => set("leftLength", e.target.value)} /></label>
          <label>پارانشیم چپ (mm)<input style={fieldStyle} type="number" value={state.leftParenchyma} onChange={(e) => set("leftParenchyma", e.target.value)} /></label>
        </div>
        {state.cystMode !== "adpkd" && (
          <label>اکوی پارانشیم
            <select style={fieldStyle} value={state.echogenicity} onChange={(e) => set("echogenicity", e.target.value)}>
              <option value="normal">طبیعی</option>
              <option value="mild">افزایش خفیف با CMD حفظ‌شده</option>
              <option value="mildModerate">خفیف تا متوسط</option>
              <option value="moderate">متوسط با کاهش CMD</option>
              <option value="severe">شدید با از بین رفتن CMD</option>
            </select>
          </label>
        )}
      </div>

      <div style={groupStyle}>
        <h3>کیست کلیه</h3>
        <label>نوع ثبت کیست
          <select style={fieldStyle} value={state.cystMode} onChange={(e) => set("cystMode", e.target.value)}>
            <option value="none">بدون کیست</option>
            <option value="single">یک کیست منفرد</option>
            <option value="multipleDetailed">چند کیست مشخص (+ افزودن)</option>
            <option value="multipleSummary">کیست‌های متعدد — گزارش بزرگ‌ترین هر کلیه</option>
            <option value="adpkd">الگوی ADPKD</option>
          </select>
        </label>

        {state.cystMode === "single" && (
          <CystFields
            value={state.cysts[0]}
            onChange={(field, value) => updateListItem("cysts", state.cysts[0].id, field, value)}
          />
        )}

        {state.cystMode === "multipleDetailed" && (
          <>
            {state.cysts.map((cyst) => (
              <CystFields
                key={cyst.id}
                value={cyst}
                onChange={(field, value) => updateListItem("cysts", cyst.id, field, value)}
                onRemove={() => removeListItem("cysts", cyst.id, makeCyst)}
                showRemove={state.cysts.length > 1}
              />
            ))}
            <button type="button" onClick={() => addListItem("cysts", makeCyst)} style={{ marginTop: "12px" }}>
              + افزودن کیست دیگر
            </button>
          </>
        )}

        {state.cystMode === "multipleSummary" && ["راست", "چپ"].map((side) => {
          const item = state.cystSummary[side];
          return (
            <div key={side} style={subCardStyle}>
              <label>
                <input type="checkbox" checked={item.enabled} onChange={(e) => updateSideSummary("cystSummary", side, "enabled", e.target.checked)} /> کیست‌های متعدد کلیه {side}
              </label>
              {item.enabled && (
                <div style={gridStyle}>
                  <label>حداقل تعداد<input style={fieldStyle} type="number" min="2" value={item.count} onChange={(e) => updateSideSummary("cystSummary", side, "count", e.target.value)} /></label>
                  <label>قطر بزرگ‌ترین (mm)<input style={fieldStyle} type="number" value={item.largestSize} onChange={(e) => updateSideSummary("cystSummary", side, "largestSize", e.target.value)} /></label>
                  <label>قطب بزرگ‌ترین<select style={fieldStyle} value={item.pole} onChange={(e) => updateSideSummary("cystSummary", side, "pole", e.target.value)}><option>فوقانی</option><option>میانی</option><option>تحتانی</option></select></label>
                  <label>نوع<select style={fieldStyle} value={item.relation} onChange={(e) => updateSideSummary("cystSummary", side, "relation", e.target.value)}><option>کورتیکال</option><option>اگزوکورتیکال</option><option>اگزوفیتیک</option><option>پاراپلویک</option></select></label>
                </div>
              )}
            </div>
          );
        })}

        {state.cystMode === "adpkd" && (
          <div style={subCardStyle}>
            <p style={{ color: "#cbd5e1" }}>طول هر دو کلیه را در بخش بالا وارد کنید. قالب یافته‌ها، نتیجه‌گیری و توصیه ADPKD قفل شده است.</p>
            <div style={gridStyle}>
              <label>بزرگ‌ترین کیست راست (mm)<input style={fieldStyle} type="number" value={state.adpkd.rightLargestSize} onChange={(e) => set("adpkd", { ...state.adpkd, rightLargestSize: e.target.value })} /></label>
              <label>قطب در کلیه راست<select style={fieldStyle} value={state.adpkd.rightPole} onChange={(e) => set("adpkd", { ...state.adpkd, rightPole: e.target.value })}><option>فوقانی</option><option>میانی</option><option>تحتانی</option></select></label>
              <label>بزرگ‌ترین کیست چپ (mm)<input style={fieldStyle} type="number" value={state.adpkd.leftLargestSize} onChange={(e) => set("adpkd", { ...state.adpkd, leftLargestSize: e.target.value })} /></label>
              <label>قطب در کلیه چپ<select style={fieldStyle} value={state.adpkd.leftPole} onChange={(e) => set("adpkd", { ...state.adpkd, leftPole: e.target.value })}><option>فوقانی</option><option>میانی</option><option>تحتانی</option></select></label>
            </div>
          </div>
        )}
      </div>

      <div style={groupStyle}>
        <h3>سنگ کلیه</h3>
        <label>نوع ثبت سنگ
          <select style={fieldStyle} value={state.stoneMode} onChange={(e) => set("stoneMode", e.target.value)}>
            <option value="none">بدون سنگ کلیه</option>
            <option value="single">یک سنگ منفرد</option>
            <option value="multipleDetailed">چند سنگ مشخص (+ افزودن)</option>
            <option value="multipleSummary">سنگ‌های متعدد — گزارش بزرگ‌ترین هر کلیه</option>
            <option value="staghorn">سنگ شاخ‌گوزنی</option>
          </select>
        </label>

        {state.stoneMode === "single" && (
          <StoneFields
            value={state.stones[0]}
            onChange={(field, value) => updateListItem("stones", state.stones[0].id, field, value)}
          />
        )}

        {state.stoneMode === "multipleDetailed" && (
          <>
            {state.stones.map((stone) => (
              <StoneFields
                key={stone.id}
                value={stone}
                onChange={(field, value) => updateListItem("stones", stone.id, field, value)}
                onRemove={() => removeListItem("stones", stone.id, makeStone)}
                showRemove={state.stones.length > 1}
              />
            ))}
            <button type="button" onClick={() => addListItem("stones", makeStone)} style={{ marginTop: "12px" }}>
              + افزودن سنگ دیگر
            </button>
          </>
        )}

        {state.stoneMode === "multipleSummary" && ["راست", "چپ"].map((side) => {
          const item = state.stoneSummary[side];
          return (
            <div key={side} style={subCardStyle}>
              <label>
                <input type="checkbox" checked={item.enabled} onChange={(e) => updateSideSummary("stoneSummary", side, "enabled", e.target.checked)} /> سنگ‌های متعدد کلیه {side}
              </label>
              {item.enabled && (
                <>
                  <div style={gridStyle}>
                    <label>قطر بزرگ‌ترین (mm)<input style={fieldStyle} type="number" value={item.largestSize} onChange={(e) => updateSideSummary("stoneSummary", side, "largestSize", e.target.value)} /></label>
                    <label>محل بزرگ‌ترین<select style={fieldStyle} value={item.calyx} onChange={(e) => updateSideSummary("stoneSummary", side, "calyx", e.target.value)}><option>کالیس فوقانی</option><option>کالیس میانی</option><option>کالیس تحتانی</option><option>لگنچه</option></select></label>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "18px", marginTop: "10px" }}>
                    <label><input type="checkbox" checked={item.shadow} onChange={(e) => updateSideSummary("stoneSummary", side, "shadow", e.target.checked)} /> سایه آکوستیک خلفی</label>
                    <label><input type="checkbox" checked={item.twinkle} onChange={(e) => updateSideSummary("stoneSummary", side, "twinkle", e.target.checked)} /> توینکل آرتیفکت</label>
                  </div>
                </>
              )}
            </div>
          );
        })}

        {state.stoneMode === "staghorn" && (
          <div style={subCardStyle}>
            <div style={gridStyle}>
              <label>سمت<select style={fieldStyle} value={state.staghorn.side} onChange={(e) => set("staghorn", { ...state.staghorn, side: e.target.value })}><option>راست</option><option>چپ</option></select></label>
              <label>قطر تجمعی (mm)<input style={fieldStyle} type="number" value={state.staghorn.size} onChange={(e) => set("staghorn", { ...state.staghorn, size: e.target.value })} /></label>
            </div>
            <p>محل‌های درگیر:</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
              {["لگنچه", "کالیس فوقانی", "کالیس میانی", "کالیس تحتانی"].map((location) => (
                <label key={location}><input type="checkbox" checked={state.staghorn.locations.includes(location)} onChange={() => toggleStaghornLocation(location)} /> {location}</label>
              ))}
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "18px", marginTop: "10px" }}>
              <label><input type="checkbox" checked={state.staghorn.shadow} onChange={(e) => set("staghorn", { ...state.staghorn, shadow: e.target.checked })} /> سایه آکوستیک خلفی</label>
              <label><input type="checkbox" checked={state.staghorn.twinkle} onChange={(e) => set("staghorn", { ...state.staghorn, twinkle: e.target.checked })} /> توینکل آرتیفکت</label>
            </div>
          </div>
        )}
      </div>

      <div style={groupStyle}>
        <h3>سنگ حالب و هیدرونفروز</h3>
        <label><input type="checkbox" checked={state.ureterStoneEnabled} onChange={(e) => set("ureterStoneEnabled", e.target.checked)} /> سنگ حالب</label>
        <div style={gridStyle}>
          {state.ureterStoneEnabled && (
            <>
              <label>سمت<select style={fieldStyle} value={state.ureterSide} onChange={(e) => set("ureterSide", e.target.value)}><option>راست</option><option>چپ</option></select></label>
              <label>محل<select style={fieldStyle} value={state.ureterLocation} onChange={(e) => set("ureterLocation", e.target.value)}><option>UPJ</option><option>پروگزیمال</option><option>میانی</option><option>دیستال</option><option>UVJ</option></select></label>
              <label>قطر سنگ (mm)<input style={fieldStyle} type="number" value={state.ureterSize} onChange={(e) => set("ureterSize", e.target.value)} /></label>
              {(state.ureterLocation === "UPJ" || state.ureterLocation === "پروگزیمال") && <label>فاصله از UPJ (mm)<input style={fieldStyle} type="number" value={state.distanceFromUPJ} onChange={(e) => set("distanceFromUPJ", e.target.value)} /></label>}
              {(state.ureterLocation === "UVJ" || state.ureterLocation === "دیستال") && <label>فاصله از UVJ (mm)<input style={fieldStyle} type="number" value={state.distanceFromUVJ} onChange={(e) => set("distanceFromUVJ", e.target.value)} /></label>}
              <label>جت حالبی سمت درگیر<select style={fieldStyle} value={state.urinaryJet} onChange={(e) => set("urinaryJet", e.target.value)}><option>بررسی نشد</option><option>طبیعی</option><option>کاهش‌یافته</option><option>مشاهده نشد</option></select></label>
            </>
          )}
          <label>هیدرونفروز<select style={fieldStyle} value={state.hydronephrosis} onChange={(e) => set("hydronephrosis", e.target.value)}><option>ندارد</option><option>خفیف</option><option>متوسط</option><option>شدید</option></select></label>
          {state.hydronephrosis !== "ندارد" && <label>AP لگنچه (mm)<input style={fieldStyle} type="number" value={state.pelvicAP} onChange={(e) => set("pelvicAP", e.target.value)} /></label>}
        </div>
        <p style={{ color: "#94a3b8" }}>در سنگ حالب، سایه آکوستیک خلفی و توینکل آرتیفکت در متن گزارش درج نمی‌شوند.</p>
      </div>

      <div style={groupStyle}>
        <h3>مثانه</h3>
        <label>الگوی مثانه
          <select style={fieldStyle} value={state.bladderMode} onChange={(e) => set("bladderMode", e.target.value)}>
            <option value="normal">شکل و ضخامت جداری طبیعی</option>
            <option value="mildDebris">ضخامت طبیعی + دبری مختصر</option>
            <option value="cystitis">افزایش ضخامت + دبری فراوان (سیستیت)</option>
            <option value="stoneDebris">دبری همراه با سنگ — احتمال هماچوری</option>
            <option value="outletObstruction">افزایش ضخامت و ترابکولاسیون</option>
          </select>
        </label>

        {(state.bladderMode === "cystitis" || state.bladderMode === "outletObstruction") && (
          <label>حداکثر ضخامت جدار (mm) — اختیاری<input style={fieldStyle} type="number" value={state.bladderWallThickness} onChange={(e) => set("bladderWallThickness", e.target.value)} /></label>
        )}

        {state.bladderMode === "stoneDebris" && (
          <label style={{ display: "block", marginTop: "12px" }}>
            <input type="checkbox" checked={state.bladderOptionalUA} onChange={(e) => set("bladderOptionalUA", e.target.checked)} /> توصیه UA به‌صورت اختیاری
          </label>
        )}

        {state.bladderMode === "outletObstruction" && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "18px", marginTop: "12px" }}>
            <label><input type="checkbox" checked={state.bladderProstateRelated} onChange={(e) => set("bladderProstateRelated", e.target.checked)} /> بزرگی پروستات همراه است</label>
            <label><input type="checkbox" checked={state.bladderMucosalIrregularity} onChange={(e) => set("bladderMucosalIrregularity", e.target.checked)} /> نامنظمی سطح مخاط</label>
            <label><input type="checkbox" checked={state.bladderDiverticulum} onChange={(e) => set("bladderDiverticulum", e.target.checked)} /> دیورتیکول مثانه</label>
          </div>
        )}
      </div>

      {showPreview && <ReportOutput {...report} />}
    </div>
  );
}

export default KidneyCard;
