import { useEffect, useMemo, useState } from "react";
import { prostateLibrary } from "../../library/Prostate/index.js";
import ReportOutput from "../Common/ReportOutput.jsx";

const initialState = {
  type: "normal",
  ml: "",
  ap: "",
  cc: "",
  echotexture: "homogeneous",
  medianLobe: false,
  medianLobeMM: "",
  periurethralCalcification: false,
  parenchymalCalcification: false,
  preVoid: "",
  pvr: "",
};

const inputStyle = {
  width: "100%",
  padding: "9px",
  marginTop: "6px",
  borderRadius: "8px",
  border: "1px solid #64748b",
};

function ProstateCard({ onReportChange, showPreview = true }) {
  const [state, setState] = useState(initialState);
  const report = useMemo(() => prostateLibrary.build(state), [state]);

  useEffect(() => {
    onReportChange?.(report);
  }, [onReportChange, report]);

  const set = (key, value) => setState((prev) => ({ ...prev, [key]: value }));

  const btn = (active) => ({
    padding: "8px 12px",
    margin: "4px",
    borderRadius: "8px",
    border: active ? "2px solid #38bdf8" : "1px solid #64748b",
    background: active ? "#0369a1" : "#334155",
    color: "white",
    cursor: "pointer",
  });

  const chooseType = (type) => {
    setState((prev) => ({
      ...prev,
      type,
      echotexture: type === "normal" ? "homogeneous" : prev.echotexture,
    }));
  };

  return (
    <div style={{ background: "#1e293b", padding: "18px", borderRadius: "14px", border: "1px solid #334155", marginTop: "18px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", alignItems: "center", flexWrap: "wrap" }}>
        <h2 style={{ margin: 0 }}>پروستات و PVR</h2>
        <button type="button" onClick={() => setState(initialState)}>پاک‌کردن فرم</button>
      </div>

      <div style={{ marginTop: "14px" }}>
        <button type="button" style={btn(state.type === "normal")} onClick={() => chooseType("normal")}>طبیعی</button>
        <button type="button" style={btn(state.type === "bph")} onClick={() => chooseType("bph")}>بزرگی خوش‌خیم‌نما</button>
        <button type="button" style={btn(state.type === "irregular")} onClick={() => chooseType("irregular")}>بزرگی نامنظم</button>
        <button type="button" style={btn(state.type === "suspicious")} onClick={() => chooseType("suspicious")}>نمای مشکوک</button>
        <button type="button" style={btn(state.type === "acuteProstatitis")} onClick={() => chooseType("acuteProstatitis")}>پروستاتیت حاد</button>
        <button type="button" style={btn(state.type === "chronicProstatitis")} onClick={() => chooseType("chronicProstatitis")}>پروستاتیت مزمن</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: "10px", marginTop: "12px" }}>
        <label>ML (mm)<input style={inputStyle} type="number" value={state.ml} onChange={(e) => set("ml", e.target.value)} /></label>
        <label>AP (mm)<input style={inputStyle} type="number" value={state.ap} onChange={(e) => set("ap", e.target.value)} /></label>
        <label>CC (mm)<input style={inputStyle} type="number" value={state.cc} onChange={(e) => set("cc", e.target.value)} /></label>
      </div>

      <h3>حجم تقریبی: {report.volume} cc</h3>

      {state.type !== "normal" && (
        <label>اکوتکچر
          <select style={inputStyle} value={state.echotexture} onChange={(e) => set("echotexture", e.target.value)}>
            <option value="homogeneous">هموژن</option>
            <option value="mildHeterogeneous">مختصراً هتروژن</option>
            <option value="heterogeneous">هتروژن</option>
          </select>
        </label>
      )}

      <div style={{ marginTop: "14px" }}>
        <label><input type="checkbox" checked={state.medianLobe} onChange={(e) => set("medianLobe", e.target.checked)} /> برجستگی لوب میانی به داخل مثانه</label>
        {state.medianLobe && (
          <input style={inputStyle} type="number" placeholder="میزان برجستگی (mm)" value={state.medianLobeMM} onChange={(e) => set("medianLobeMM", e.target.value)} />
        )}
      </div>

      <div style={{ marginTop: "12px", display: "grid", gap: "8px" }}>
        <label><input type="checkbox" checked={state.periurethralCalcification} onChange={(e) => set("periurethralCalcification", e.target.checked)} /> کلسیفیکاسیون پری‌یورترال</label>
        <label><input type="checkbox" checked={state.parenchymalCalcification} onChange={(e) => set("parenchymalCalcification", e.target.checked)} /> کلسیفیکاسیون پارانشیمی</label>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: "10px", marginTop: "14px" }}>
        <label>حجم مثانه قبل از تخلیه (mL)<input style={inputStyle} type="number" value={state.preVoid} onChange={(e) => set("preVoid", e.target.value)} /></label>
        <label>PVR (mL)<input style={inputStyle} type="number" value={state.pvr} onChange={(e) => set("pvr", e.target.value)} /></label>
      </div>

      {showPreview && <ReportOutput finding={report.finding} impression={report.impression} recommendation={report.recommendation} />}
    </div>
  );
}

export default ProstateCard;
