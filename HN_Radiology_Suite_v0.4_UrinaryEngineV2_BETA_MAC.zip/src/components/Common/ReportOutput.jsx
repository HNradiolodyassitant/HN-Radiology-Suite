import { useMemo, useState } from "react";

const sectionStyle = {
  background: "#0f172a",
  border: "1px solid #334155",
  borderRadius: "10px",
  padding: "14px",
  whiteSpace: "pre-wrap",
  lineHeight: 2,
  minHeight: "64px",
};

function ReportOutput({ finding = "", impression = "", recommendation = "" }) {
  const [copyStatus, setCopyStatus] = useState("");

  const fullReport = useMemo(() => {
    const sections = [];
    if (finding.trim()) sections.push(`یافته‌ها:\n${finding.trim()}`);
    if (impression.trim()) sections.push(`نتیجه‌گیری:\n${impression.trim()}`);
    if (recommendation.trim()) sections.push(`پیشنهاد:\n${recommendation.trim()}`);
    return sections.join("\n\n");
  }, [finding, impression, recommendation]);

  const copyReport = async () => {
    try {
      await navigator.clipboard.writeText(fullReport);
      setCopyStatus("گزارش کپی شد");
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = fullReport;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopyStatus("گزارش کپی شد");
    }

    window.setTimeout(() => setCopyStatus(""), 1800);
  };

  return (
    <div style={{ marginTop: "24px" }}>
      <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
        <h3 style={{ margin: 0 }}>پیش‌نمایش گزارش</h3>
        <button type="button" onClick={copyReport} style={{ padding: "8px 14px", cursor: "pointer" }}>
          کپی گزارش
        </button>
        {copyStatus && <span style={{ color: "#86efac" }}>{copyStatus}</span>}
      </div>

      <h4>یافته‌ها</h4>
      <div style={sectionStyle}>{finding || "—"}</div>

      <h4>نتیجه‌گیری</h4>
      <div style={sectionStyle}>{impression || "—"}</div>

      {recommendation && (
        <>
          <h4>پیشنهاد</h4>
          <div style={sectionStyle}>{recommendation}</div>
        </>
      )}
    </div>
  );
}

export default ReportOutput;
