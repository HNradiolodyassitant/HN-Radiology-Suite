export function buildRecommendation(recommendations) {
  if (!recommendations || recommendations.length === 0) {
    return "";
  }

  return recommendations.join("\n");
}