export function createReport(cards) {
  const findings = [];
  const impressions = [];
  const recommendations = [];

  cards.forEach((card) => {
    if (!card) return;

    if (card.finding) findings.push(card.finding);

    if (card.impression) impressions.push(card.impression);

    if (card.recommendation)
      recommendations.push(card.recommendation);
  });

  return {
    findings,
    impressions,
    recommendations,
  };
}