export function buildImpression(impressions) {
  if (!impressions || impressions.length === 0) {
    return "بررسی سونوگرافی در محدوده طبیعی است.";
  }

  return impressions.join("\n");
}