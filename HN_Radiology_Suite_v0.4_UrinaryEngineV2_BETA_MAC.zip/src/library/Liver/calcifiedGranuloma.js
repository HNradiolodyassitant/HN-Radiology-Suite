export const calcifiedGranulomaLibrary = {
  build(size, location) {
    return {
      finding: `یک کانون کلسیفیه به قطر ${size} میلی‌متر در ${location} کبد رویت شد که می‌تواند مطرح‌کننده گرانولوم کلسیفیه باشد.`,
      impression: "گرانولوم کلسیفیه کبد.",
      recommendation: "",
    };
  },
};