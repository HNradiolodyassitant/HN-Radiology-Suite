export const metastasisLibrary = {
  solitary: {
    build(size, location) {
      return {
        finding: `یک ضایعه سالید به قطر ${size} میلی‌متر در ${location} کبد رویت شد که در صورت سابقه بدخیمی می‌تواند مطرح‌کننده متاستاز باشد.`,
        impression: "ضایعه کبدی مشکوک به متاستاز.",
        recommendation:
          "در صورت سابقه بدخیمی، بررسی تکمیلی با MRI Dynamic Liver یا CT سه‌فازی توصیه می‌شود.",
      };
    },
  },

  multiple: {
    build(maxSize) {
      return {
        finding: `چندین ضایعه سالید در هر دو لوب کبد تا بزرگترین قطر ${maxSize} میلی‌متر رویت شد که در صورت سابقه بدخیمی می‌تواند مطرح‌کننده متاستاز باشد.`,
        impression: "ضایعات متعدد کبدی مشکوک به متاستاز.",
        recommendation:
          "MRI Dynamic Liver یا CT سه‌فازی و تطابق با سابقه بالینی توصیه می‌شود.",
      };
    },
  },
};