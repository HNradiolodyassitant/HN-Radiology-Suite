export const hydatidCystLibrary = {
  suspected: {
    build(size, location) {
      return {
        finding: `یک ضایعه کیستیک به قطر ${size} میلی‌متر در ${location} کبد با نمای مشکوک به کیست هیداتید رویت شد.`,
        impression: "ضایعه کیستیک کبد با احتمال کیست هیداتید.",
        recommendation: "تطابق با یافته‌های آزمایشگاهی و بررسی تکمیلی با CT یا MRI کبد توصیه می‌شود.",
      };
    },
  },
};