export const liverCystLibrary = {
  simple: {
    build(size, location) {
      return {
        finding: `یک کیست ساده به قطر ${size} میلی‌متر در ${location} کبد رویت شد.`,
        impression: "کیست ساده کبد.",
        recommendation: "",
      };
    },
  },
};