export const focalLesionLibrary = {
  solid: {
    build(type, size, location) {
      return {
        finding: `یک ضایعه سالید ${type} به قطر ${size} میلی‌متر در ${location} کبد رویت شد.`,
        impression: "ضایعه سالید کبد.",
        recommendation:
          "بررسی تکمیلی با MRI Dynamic Liver یا CT سه‌فازی کبد توصیه می‌شود.",
      };
    },
  },
};