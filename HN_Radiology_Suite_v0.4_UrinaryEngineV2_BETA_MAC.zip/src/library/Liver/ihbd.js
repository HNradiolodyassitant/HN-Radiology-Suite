export const ihbdLibrary = {
  mild: {
    build() {
      return {
        finding:
          "اتساع خفیف مجاری صفراوی داخل کبدی (IHBD) رویت شد.",
        impression:
          "اتساع خفیف مجاری صفراوی داخل کبدی.",
        recommendation:
          "بررسی مجرای صفراوی خارج کبدی و در صورت اندیکاسیون بالینی، MRCP توصیه می‌شود.",
      };
    },
  },

  moderate: {
    build() {
      return {
        finding:
          "اتساع متوسط مجاری صفراوی داخل کبدی (IHBD) رویت شد.",
        impression:
          "اتساع متوسط مجاری صفراوی داخل کبدی.",
        recommendation:
          "بررسی تکمیلی با MRCP یا CT با کنتراست بر اساس شرایط بالینی توصیه می‌شود.",
      };
    },
  },

  severe: {
    build() {
      return {
        finding:
          "اتساع شدید مجاری صفراوی داخل کبدی (IHBD) رویت شد.",
        impression:
          "اتساع شدید مجاری صفراوی داخل کبدی.",
        recommendation:
          "بررسی فوری علت انسداد با MRCP یا CT و ارجاع به متخصص گوارش توصیه می‌شود.",
      };
    },
  },
};