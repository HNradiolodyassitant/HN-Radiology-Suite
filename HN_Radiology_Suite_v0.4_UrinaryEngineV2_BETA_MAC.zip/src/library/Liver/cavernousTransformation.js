export const cavernousTransformationLibrary = {
  build() {
    return {
      finding:
        "تصویر عروق کلا‌ترال متعدد در ناحیه پورتا هپاتیس به نفع cavernous transformation ورید پورت رویت شد.",
      impression: "Cavernous transformation ورید پورت.",
      recommendation:
        "بررسی تکمیلی با کالر داپلر و ارزیابی علت زمینه‌ای توصیه می‌شود.",
    };
  },
};