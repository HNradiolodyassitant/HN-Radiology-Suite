export const coarseParenchymaLibrary = {
  build() {
    return {
      finding:
        "اکوتکستچر پارانشیم کبد به صورت منتشر خشن (Coarse) مشاهده شد.",
      impression: "تغییرات منتشر اکوتکستچر کبد.",
      recommendation:
        "در صورت اندیکاسیون بالینی، بررسی از نظر بیماری مزمن کبدی توصیه می‌شود.",
    };
  },
};