export const periportalEdemaLibrary = {
  build() {
    return {
      finding:
        "افزایش اکوی اطراف شاخه‌های پورت به صورت periportal echogenicity/edema رویت شد.",
      impression: "Periportal edema.",
      recommendation:
        "تطابق با وضعیت بالینی، آزمایش‌های کبدی و علل التهابی یا احتقانی توصیه می‌شود.",
    };
  },
};