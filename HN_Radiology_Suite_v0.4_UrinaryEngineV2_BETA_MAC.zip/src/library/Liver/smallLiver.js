export const smallLiverLibrary = {
  build(ccLength) {
    return {
      finding: `اندازه کبد کاهش یافته و قطر کرانیوکودال لوب راست حدود ${ccLength} میلی‌متر اندازه‌گیری شد.`,
      impression: "کوچک شدن کبد.",
      recommendation: "تطابق با سایر یافته‌های تصویربرداری و بالینی توصیه می‌شود.",
    };
  },
};