export const periportalEchogenicityLibrary = {
  build() {
    return {
      finding:
        "افزایش اکوی اطراف شاخه‌های پورت به صورت periportal echogenicity مشاهده شد.",
      impression: "افزایش periportal echogenicity.",
      recommendation:
        "تطابق با یافته‌های بالینی و آزمایشگاهی توصیه می‌شود.",
    };
  },
};