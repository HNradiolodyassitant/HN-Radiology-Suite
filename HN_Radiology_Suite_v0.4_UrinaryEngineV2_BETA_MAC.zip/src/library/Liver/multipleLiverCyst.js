export const multipleLiverCystLibrary = {
  simple: {
    build(maxSize, location = "کبد") {
      return {
        finding: `تصویر چند کیست ساده تا بزرگترین قطر ${maxSize} میلی‌متر در ${location} رویت شد.`,
        impression: "کیست‌های ساده متعدد کبد.",
        recommendation: "",
      };
    },
  },
};