export const portalVeinThrombosisLibrary = {
  build(type = "partial") {
    const typeFa = type === "complete" ? "کامل" : "نسبی";

    return {
      finding: `شواهد ترومبوز ${typeFa} ورید پورت رویت شد.`,
      impression: `ترومبوز ${typeFa} ورید پورت.`,
      recommendation:
        "بررسی تکمیلی با کالر داپلر و تطابق با یافته‌های بالینی و آزمایشگاهی توصیه می‌شود.",
    };
  },
};