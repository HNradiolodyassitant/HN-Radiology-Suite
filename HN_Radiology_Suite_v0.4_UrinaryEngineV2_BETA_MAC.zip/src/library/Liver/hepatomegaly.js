export const hepatomegalyLibrary = {
  build(ccLength) {
    return {
      finding: `اندازه کبد افزایش یافته و قطر کرانیوکودال لوب راست حدود ${ccLength} میلی‌متر اندازه‌گیری شد.`,
      impression: "هپاتومگالی.",
      recommendation: "",
    };
  },
};