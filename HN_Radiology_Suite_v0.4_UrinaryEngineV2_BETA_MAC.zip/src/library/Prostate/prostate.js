const calcVolume = (ml, ap, cc) => {
  const values = [ml, ap, cc].map(Number);
  if (values.some((value) => !Number.isFinite(value) || value <= 0)) return "…";
  return ((values[0] * values[1] * values[2] * 0.52) / 1000).toFixed(1);
};

const medianLobeGrade = (mm) => {
  const value = Number(mm);
  if (!Number.isFinite(value) || value <= 0) return "";
  if (value < 5) return "Grade I";
  if (value <= 10) return "Grade II";
  return "Grade III";
};

const pvrStatus = (pvr) => {
  if (pvr === "" || pvr === null || pvr === undefined) return null;
  const value = Number(pvr);
  if (!Number.isFinite(value) || value < 0) return null;

  if (value < 50) return { impression: "تخلیه مثانه مناسب است.", recommendation: "" };
  if (value <= 100) return { impression: "PVR در محدوده قابل قبول اندازه‌گیری شد.", recommendation: "تفسیر این مقدار بر اساس علائم بالینی انجام شود." };
  if (value <= 200) return { impression: "افزایش خفیف PVR و تخلیه ناکامل مثانه.", recommendation: "تطابق با علائم ادراری و ارزیابی اورولوژی توصیه می‌شود." };
  if (value <= 300) return { impression: "افزایش متوسط تا شدید PVR.", recommendation: "ارزیابی تخصصی اورولوژی جهت بررسی انسداد خروجی مثانه یا اختلال عملکرد دترسور توصیه می‌شود." };
  return { impression: "احتباس قابل توجه ادرار.", recommendation: "ارزیابی اورولوژی در اسرع وقت توصیه می‌شود." };
};

export const prostateLibrary = {
  build({
    type,
    ml,
    ap,
    cc,
    echotexture,
    medianLobe,
    medianLobeMM,
    periurethralCalcification,
    parenchymalCalcification,
    preVoid,
    pvr,
  }) {
    const volume = calcVolume(ml, ap, cc);
    const grade = medianLobeGrade(medianLobeMM);
    const pvrInfo = pvrStatus(pvr);

    const echoText = {
      homogeneous: "هموژن",
      mildHeterogeneous: "مختصراً هتروژن",
      heterogeneous: "هتروژن",
    }[echotexture] || "هموژن";

    const hasDimensions = volume !== "…";
    let finding = hasDimensions
      ? `پروستات به ابعاد ${ml} × ${ap} × ${cc} میلی‌متر و حجم تقریبی ${volume} سی‌سی اندازه‌گیری شد. `
      : "پروستات مورد بررسی قرار گرفت. ";

    const typeFinding = {
      normal: "ابعاد پروستات در محدوده طبیعی بوده، حدود آن صاف و منظم و اکوتکچر پارانشیم هموژن است. ضایعه فوکال مشکوکی در بررسی سونوگرافی مشاهده نشد.",
      bph: "افزایش حجم پروستات با غلبه بزرگ‌شدگی ناحیه ترانزیشنال و حدود صاف و منظم مشاهده شد. این نما در صورت تطابق بالینی می‌تواند در زمینه بزرگی خوش‌خیم پروستات مطرح باشد.",
      irregular: "پروستات بزرگ‌شده و دارای اکوتکچر هتروژن و حدود نامنظم است. تعیین ماهیت تغییرات صرفاً بر اساس سونوگرافی امکان‌پذیر نیست.",
      suspicious: "پروستات دارای اکوتکچر هتروژن، حدود نامنظم و نمای غیرتیپیک است و ضایعه مشکوک پروستات باید مدنظر قرار گیرد.",
      acuteProstatitis: "پروستات افزایش حجم داشته و اکوتکچر پارانشیم آن به صورت منتشر هتروژن است. در صورت افزایش واسکولاریته در کالر داپلر، یافته‌ها می‌تواند با پروستاتیت حاد تطابق داشته باشد. آبسه واضحی مشاهده نشد.",
      chronicProstatitis: "اکوتکچر پارانشیم پروستات هتروژن است و نمای موجود در صورت تطابق بالینی می‌تواند در زمینه تغییرات التهابی مزمن مطرح باشد.",
    }[type];

    finding += typeFinding || "";

    if (type !== "normal") finding += ` اکوتکچر پروستات ${echoText} است.`;

    if (medianLobe && medianLobeMM) {
      finding += ` برجستگی لوب میانی پروستات به داخل قاعده مثانه به میزان ${medianLobeMM} میلی‌متر مشاهده شد${grade ? ` (${grade})` : ""}.`;
    }

    if (periurethralCalcification && parenchymalCalcification) {
      finding += " کلسیفیکاسیون‌های پری‌یورترال و پارانشیمی پروستات مشاهده شد.";
    } else if (periurethralCalcification) {
      finding += " کلسیفیکاسیون‌های پری‌یورترال پروستات مشاهده شد.";
    } else if (parenchymalCalcification) {
      finding += " کلسیفیکاسیون‌های پارانشیمی پروستات مشاهده شد.";
    }

    if (preVoid !== "") finding += ` حجم مثانه پیش از تخلیه حدود ${preVoid} میلی‌لیتر اندازه‌گیری شد.`;
    if (pvr !== "") finding += ` حجم ادرار باقی‌مانده پس از تخلیه (PVR) حدود ${pvr} میلی‌لیتر اندازه‌گیری شد.`;

    const impressionMap = {
      normal: hasDimensions ? `پروستات با حجم تقریبی ${volume} سی‌سی و نمای طبیعی.` : "نمای طبیعی پروستات.",
      bph: hasDimensions ? `بزرگی پروستات با نمای خوش‌خیم‌نما و حجم تقریبی ${volume} سی‌سی.` : "بزرگی پروستات با نمای خوش‌خیم‌نما.",
      irregular: "بزرگی پروستات با اکوتکچر هتروژن و حدود نامنظم.",
      suspicious: "نمای مشکوک پروستات؛ بررسی تکمیلی ضروری است.",
      acuteProstatitis: "نمای سونوگرافیک مطرح‌کننده پروستاتیت حاد در صورت تطابق بالینی.",
      chronicProstatitis: "نمای مطرح‌کننده تغییرات التهابی مزمن پروستات در صورت تطابق بالینی.",
    };

    const recommendationMap = {
      normal: "",
      bph: "تطابق با علائم ادراری، معاینه بالینی و PSA و در صورت نیاز ارزیابی اورولوژی توصیه می‌شود.",
      irregular: "تطابق با PSA و معاینه بالینی و ارزیابی تخصصی اورولوژی توصیه می‌شود. در صورت شک بالینی، انجام mpMRI پروستات پیشنهاد می‌گردد.",
      suspicious: "تطابق با PSA، معاینه بالینی و ارزیابی اورولوژی توصیه می‌شود. انجام mpMRI پروستات جهت بررسی دقیق‌تر پیشنهاد می‌گردد.",
      acuteProstatitis: "تطابق با علائم بالینی، آزمایش ادرار و مارکرهای التهابی و پیگیری توسط پزشک معالج/اورولوژیست توصیه می‌شود.",
      chronicProstatitis: "تطابق با شرح حال، علائم ادراری، آزمایش ادرار و PSA و ارزیابی اورولوژی توصیه می‌شود.",
    };

    const recommendations = [recommendationMap[type], pvrInfo?.recommendation].filter(Boolean);

    return {
      finding,
      impression: `${impressionMap[type] || ""}${pvrInfo ? ` ${pvrInfo.impression}` : ""}`.trim(),
      recommendation: [...new Set(recommendations)].join(" "),
      volume,
      medianLobeGrade: grade,
    };
  },
};
