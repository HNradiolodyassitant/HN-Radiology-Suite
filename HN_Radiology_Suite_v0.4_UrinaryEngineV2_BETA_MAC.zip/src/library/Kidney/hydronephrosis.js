export const hydronephrosisLibrary = {
  build({ side, grade, pelvicAP = "" }) {
    if (!side || !grade || grade === "ندارد") return null;

    return {
      finding:
        `هیدرونفروز ${grade} در کلیه ${side} رویت شد` +
        (pelvicAP ? ` و قطر قدامی‌خلفی لگنچه داخل کلیه حدود ${pelvicAP} میلی‌متر اندازه‌گیری شد.` : "."),
      impression: `هیدرونفروز ${grade} کلیه ${side}.`,
      recommendation: "تطابق با علائم بالینی و بررسی مسیر حالب جهت تعیین علت انسداد توصیه می‌شود.",
    };
  },
};
