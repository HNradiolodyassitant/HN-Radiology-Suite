export const bladderLibrary = {
  build({
    mode = "normal",
    wallThickness = "",
    optionalUA = false,
    prostateRelated = false,
    mucosalIrregularity = false,
    diverticulum = false,
    hasUrinaryStone = false,
  }) {
    if (mode === "normal") {
      return {
        finding: "مثانه دارای شکل و ضخامت جداری طبیعی بوده و فاقد سنگ یا ضایعه فضاگیر است.",
        impression: "",
        recommendation: "",
      };
    }

    if (mode === "mildDebris") {
      return {
        finding:
          "مثانه دارای شکل و ضخامت جداری طبیعی است. مقدار مختصری دبری اکوژن شناور در داخل مثانه رویت شد که می‌تواند در زمینه کریستالوری، هماچوری، پیوری یا استاز ادراری باشد.",
        impression: "دبری اکوژن مختصر داخل مثانه.",
        recommendation: "تطابق با یافته‌های آزمایش کامل ادرار (UA) توصیه می‌شود.",
      };
    }

    if (mode === "cystitis") {
      const thicknessText = wallThickness
        ? ` تا حداکثر ${wallThickness} میلی‌متر`
        : "";
      return {
        finding:
          `افزایش ضخامت جدار مثانه${thicknessText} همراه با دبری‌های اکوژن شناور فراوان در داخل آن رویت شد. ` +
          "با توجه به شرح حال و علائم بالینی بیمار، یافته‌ها می‌توانند مطرح‌کننده سیستیت باشند.",
        impression: "نمای مطرح‌کننده سیستیت در صورت تطابق بالینی.",
        recommendation:
          "بررسی آزمایش کامل ادرار (UA) و کشت ادرار (UC) توصیه می‌شود.",
      };
    }

    if (mode === "stoneDebris") {
      const finding = hasUrinaryStone
        ? "دبری‌های اکوژن شناور در داخل مثانه رویت شد که با توجه به وجود سنگ در سیستم ادراری، می‌تواند مطرح‌کننده هماچوری باشد."
        : "دبری‌های اکوژن شناور در داخل مثانه رویت شد. با توجه به عدم ثبت سنگ در سیستم ادراری، تعیین علت بر اساس شرح حال و یافته‌های آزمایشگاهی انجام شود.";

      return {
        finding,
        impression: hasUrinaryStone
          ? "دبری مثانه، احتمالاً در زمینه هماچوری مرتبط با سنگ سیستم ادراری."
          : "دبری اکوژن داخل مثانه.",
        recommendation: optionalUA
          ? "تطابق با یافته‌های آزمایش کامل ادرار (UA) توصیه می‌شود."
          : "",
      };
    }

    if (mode === "outletObstruction") {
      const thicknessText = wallThickness
        ? ` تا حداکثر ${wallThickness} میلی‌متر`
        : "";
      const extra = [];
      if (mucosalIrregularity) extra.push("نامنظمی سطح مخاط");
      if (diverticulum) extra.push("دیورتیکول مثانه");
      const extraText = extra.length ? ` همراه با ${extra.join(" و ")}` : "";
      const causeText = prostateRelated
        ? "که با توجه به بزرگی پروستات، احتمالاً ثانویه به انسداد مزمن خروجی مثانه است"
        : "که می‌تواند در زمینه انسداد مزمن خروجی مثانه باشد";

      return {
        finding: `افزایش ضخامت${thicknessText} و ترابکولاسیون جدار مثانه${extraText} مشاهده شد ${causeText}.`,
        impression: prostateRelated
          ? "تغییرات مزمن جدار مثانه در زمینه انسداد خروجی مثانه، احتمالاً مرتبط با بزرگی پروستات."
          : "تغییرات مزمن جدار مثانه، مطرح‌کننده انسداد خروجی مثانه.",
        recommendation:
          "تطابق با علائم ادراری، حجم ادرار باقی‌مانده پس از تخلیه (PVR) و در صورت نیاز ارزیابی اورولوژی توصیه می‌شود.",
      };
    }

    return null;
  },
};
