export const simpleCystLibrary = {
  build({ side, pole, size, relation = "کورتیکال" }) {
    if (!side || !pole || !size) return null;

    return {
      finding: `یک کیست ساده ${relation} در قطب ${pole} کلیه ${side} به قطر ${size} میلی‌متر رویت شد.`,
      impression: `کیست ساده کلیه ${side}.`,
      recommendation: "",
    };
  },
};
