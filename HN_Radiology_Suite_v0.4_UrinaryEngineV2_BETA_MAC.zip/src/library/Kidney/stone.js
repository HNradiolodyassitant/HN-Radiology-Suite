const joinFa = (items) => {
  if (items.length <= 1) return items[0] || "";
  return `${items.slice(0, -1).join("، ")} و ${items.at(-1)}`;
};

const featureText = ({ shadow, twinkle }) => {
  const features = [];
  if (shadow) features.push("سایه آکوستیک خلفی");
  if (twinkle) features.push("توینکل آرتیفکت");
  return features.length ? ` همراه با ${features.join(" و ")}` : "";
};

const stoneDescription = (stone) =>
  `سنگ ${stone.size || "…"} میلی‌متری در ${stone.calyx || "…"}${featureText(stone)}`;

const ctRecommendation =
  "در صورت صلاحدید پزشک معالج، جهت ارزیابی دقیق‌تر تعداد، موقعیت و بار سنگی، انجام CT scan شکم و لگن بدون تزریق ماده حاجب توصیه می‌شود.";

export const kidneyStoneLibrary = {
  single: {
    build({ side, calyx, size, shadow, twinkle }) {
      if (!side || !calyx || !size) return null;
      return {
        finding:
          `یک سنگ به قطر ${size} میلی‌متر در ${calyx} کلیه ${side}${featureText({ shadow, twinkle })} رویت شد.`,
        impression: `سنگ کلیه ${side}.`,
        recommendation: "",
      };
    },
  },

  multipleDetailed: {
    build(stones = []) {
      const valid = stones.filter((stone) => stone?.side && stone?.calyx && stone?.size);
      if (!valid.length) return null;

      const findings = ["راست", "چپ"]
        .map((side) => {
          const sideStones = valid.filter((stone) => stone.side === side);
          if (!sideStones.length) return "";
          return `تصویر ${sideStones.length} سنگ در کلیه ${side} شامل ${joinFa(
            sideStones.map(stoneDescription)
          )} رویت شد.`;
        })
        .filter(Boolean);

      const largest = valid.reduce((max, stone) =>
        Number(stone.size) > Number(max.size) ? stone : max
      );
      const sides = [...new Set(valid.map((stone) => stone.side))];

      return {
        finding: findings.join("\n"),
        impression:
          sides.length === 2
            ? `سنگ‌های متعدد دوطرفه کلیه‌ها؛ بزرگ‌ترین سنگ ${largest.size} میلی‌متر است.`
            : `سنگ‌های متعدد کلیه ${sides[0]}؛ بزرگ‌ترین سنگ ${largest.size} میلی‌متر است.`,
        recommendation: ctRecommendation,
      };
    },
  },

  multipleSummary: {
    build(summary = {}) {
      const entries = ["راست", "چپ"]
        .map((side) => ({ side, ...(summary[side] || {}) }))
        .filter((entry) => entry.enabled && entry.largestSize && entry.calyx);
      if (!entries.length) return null;

      const findings = entries.map(
        ({ side, largestSize, calyx, shadow, twinkle }) =>
          `تصویر سنگ‌های متعدد در کلیه ${side} رویت شد که بزرگ‌ترین آن‌ها به قطر ${largestSize} میلی‌متر در ${calyx}${featureText({ shadow, twinkle })} است.`
      );

      return {
        finding: findings.join("\n"),
        impression:
          entries.length === 2
            ? "سنگ‌های متعدد دوطرفه کلیه‌ها."
            : `سنگ‌های متعدد کلیه ${entries[0].side}.`,
        recommendation: ctRecommendation,
      };
    },
  },

  staghorn: {
    build({ side, locations = [], size, shadow, twinkle }) {
      if (!side || !locations.length || !size) return null;
      const locationText = joinFa(locations);
      return {
        finding:
          `یک سنگ با نمای شاخ‌گوزنی، درگیرکننده ${locationText} کلیه ${side}، با قطر تجمعی حدود ${size} میلی‌متر${featureText({ shadow, twinkle })} رویت شد.`,
        impression: `سنگ شاخ‌گوزنی کلیه ${side}.`,
        recommendation:
          "ارزیابی تخصصی اورولوژی و در صورت نیاز CT scan بدون تزریق جهت تعیین دقیق بار سنگی و برنامه‌ریزی درمان توصیه می‌شود.",
      };
    },
  },
};
