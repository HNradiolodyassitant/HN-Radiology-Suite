const sideLabel = (side) => `کلیه ${side}`;

const joinFa = (items) => {
  if (items.length <= 1) return items[0] || "";
  return `${items.slice(0, -1).join("، ")} و ${items.at(-1)}`;
};

const cystDescription = ({ relation = "کورتیکال", size, pole }) =>
  `یک کیست ساده ${relation} به قطر ${size || "…"} میلی‌متر در قطب ${pole || "…"}`;

export const renalCystLibrary = {
  single: {
    build({ side, pole, size, relation = "کورتیکال" }) {
      if (!side || !pole || !size) return null;

      return {
        finding: `یک کیست ساده ${relation} در قطب ${pole} کلیه ${side} به قطر ${size} میلی‌متر رویت شد.`,
        impression: `کیست ساده کلیه ${side}.`,
        recommendation: "",
      };
    },
  },

  multipleDetailed: {
    build(cysts = []) {
      const valid = cysts.filter((item) => item?.side && item?.pole && item?.size);
      if (!valid.length) return null;

      const findings = ["راست", "چپ"]
        .map((side) => {
          const sideCysts = valid.filter((item) => item.side === side);
          if (!sideCysts.length) return "";
          const descriptions = sideCysts.map(cystDescription);
          return `تصویر ${sideCysts.length} کیست ساده در ${sideLabel(side)} شامل ${joinFa(descriptions)} مشاهده شد.`;
        })
        .filter(Boolean);

      const sides = [...new Set(valid.map((item) => item.side))];
      const impression =
        sides.length === 2
          ? "کیست‌های ساده متعدد دوطرفه کلیه‌ها."
          : `کیست‌های ساده متعدد کلیه ${sides[0]}.`;

      return {
        finding: findings.join("\n"),
        impression,
        recommendation: "",
      };
    },
  },

  multipleSummary: {
    build(summary = {}) {
      const entries = ["راست", "چپ"]
        .map((side) => ({ side, ...(summary[side] || {}) }))
        .filter((item) => item.enabled && item.largestSize && item.pole);

      if (!entries.length) return null;

      const findings = entries.map(
        ({ side, count = "3", largestSize, pole, relation = "کورتیکال" }) =>
          `تصویر چند کیست ساده (حداقل ${count || "3"} عدد) در کلیه ${side} رویت شد که بزرگ‌ترین آن‌ها یک کیست ${relation} به قطر ${largestSize} میلی‌متر در قطب ${pole} است.`
      );

      return {
        finding: findings.join("\n"),
        impression:
          entries.length === 2
            ? "کیست‌های ساده متعدد دوطرفه کلیه‌ها."
            : `کیست‌های ساده متعدد کلیه ${entries[0].side}.`,
        recommendation: "",
      };
    },
  },

  adpkd: {
    build({
      rightLength,
      leftLength,
      rightLargestSize,
      rightPole,
      leftLargestSize,
      leftPole,
      noStoneOrHydronephrosis = true,
    }) {
      let finding =
        "هر دو کلیه بزرگ‌تر از حد طبیعی بوده و مورفولوژی طبیعی آن‌ها به‌دلیل وجود تعداد بسیار زیادی کیست با ابعاد متفاوت و توزیع منتشر کورتیکومدولاری تغییر یافته است. " +
        `طول کلیه راست ${rightLength || "……"} و کلیه چپ ${leftLength || "……"} میلی‌متر است. ` +
        `بزرگ‌ترین کیست در کلیه راست به قطر ${rightLargestSize || "……"} میلی‌متر در قطب ${rightPole || "……"} و در کلیه چپ به قطر ${leftLargestSize || "……"} میلی‌متر در قطب ${leftPole || "……"} مشاهده شد. ` +
        "کیست‌های قابل‌ارزیابی دارای دیواره نازک و محتوای ساده بوده و جزء جامد مشکوکی در آن‌ها دیده نشد.";

      if (noStoneOrHydronephrosis) {
        finding += " شواهدی از سنگ یا هیدرونفروز واضح مشاهده نشد.";
      }

      return {
        finding,
        impression:
          "نمای سونوگرافیک کلیه‌ها، در تطابق با سابقه بالینی و خانوادگی، به نفع بیماری کلیه پلی‌کیستیک اتوزومال غالب (ADPKD) است.",
        recommendation:
          "بررسی عملکرد کلیه شامل BUN، Cr و eGFR و پیگیری توسط متخصص نفرولوژی توصیه می‌شود.",
      };
    },
  },
};

// Backward-compatible export for older modules.
export const simpleCystLibrary = {
  build: renalCystLibrary.single.build,
};
