const jetFinding = (side, status) => {
  if (!status || status === "بررسی نشد") return "";
  if (status === "طبیعی") return ` جت حالبی سمت ${side} در مدت بررسی با نمای طبیعی مشاهده شد.`;
  if (status === "کاهش‌یافته") return ` جت حالبی سمت ${side} در مدت بررسی کاهش‌یافته بود.`;
  if (status === "مشاهده نشد") return ` جت حالبی سمت ${side} در مدت بررسی مشاهده نشد.`;
  return "";
};

export const ureterStoneLibrary = {
  build({
    side,
    location,
    size,
    distanceFromUPJ = "",
    distanceFromUVJ = "",
    hydronephrosis = "ندارد",
    pelvicAP = "",
    urinaryJet = "بررسی نشد",
  }) {
    if (!side || !location || !size) return null;

    const locationText =
      location === "UPJ" || location === "UVJ"
        ? `ناحیه ${location}`
        : `قسمت ${location} حالب`;

    let finding = `یک سنگ به قطر ${size} میلی‌متر در ${locationText} ${side}`;

    if ((location === "پروگزیمال" || location === "UPJ") && distanceFromUPJ) {
      finding += `، در فاصله ${distanceFromUPJ} میلی‌متری از UPJ`;
    }

    if ((location === "دیستال" || location === "UVJ") && distanceFromUVJ) {
      finding += `، در فاصله ${distanceFromUVJ} میلی‌متری از UVJ`;
    }

    finding += " رویت شد.";

    if (hydronephrosis !== "ندارد") {
      finding += ` هیدرویورترونفروز ${hydronephrosis} در سمت ${side} مشاهده شد`;
      if (pelvicAP) finding += ` و قطر AP لگنچه داخل کلیه ${pelvicAP} میلی‌متر اندازه‌گیری شد`;
      finding += ".";
    }

    finding += jetFinding(side, urinaryJet);

    return {
      finding,
      impression:
        hydronephrosis === "ندارد"
          ? `سنگ حالب ${side}.`
          : `سنگ حالب ${side} همراه با هیدرویورترونفروز ${hydronephrosis}.`,
      recommendation: "",
    };
  },
};
