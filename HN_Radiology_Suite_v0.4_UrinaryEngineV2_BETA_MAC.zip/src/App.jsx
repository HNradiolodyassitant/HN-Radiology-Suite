import "./App.css";
import Home from "./components/Home";
import Ultrasound from "./components/Ultrasound";
import { useState } from "react";

function App() {
  const [page, setPage] = useState("home");

  return (
    <>
      {page === "home" && <Home goUltrasound={() => setPage("ultrasound")} />}
      {page === "ultrasound" && <Ultrasound goBack={() => setPage("home")} />}
    </>
  );
}

export default App;