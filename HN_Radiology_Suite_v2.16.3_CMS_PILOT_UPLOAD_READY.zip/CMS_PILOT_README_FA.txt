CMS Pilot v2.16.3
- Copy for CMS: plain-text and character normalization.
- Patient identity lock using Patient ID + patient name.
- CSV/TXT admission-list import and Patient ID lookup.
- CMS Bridge packet export for safe integration testing.
- No direct write to the clinic CMS/database is performed in this pilot.
