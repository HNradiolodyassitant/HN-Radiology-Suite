type AppEnv = Env & { BOOTSTRAP_TOKEN?: string };

type Role = "owner" | "radiologist" | "secretary" | "viewer";

type Actor = {
  sessionId: string;
  id: string;
  organizationId: string;
  email: string;
  displayName: string;
  role: Role;
  organizationName: string;
  organizationStatus: "active" | "suspended";
  subscriptionExpiresAt: string | null;
};

type UserRow = {
  id: string;
  organization_id: string;
  email: string;
  display_name: string;
  role: Role;
  active: number;
  password_salt: string | null;
  password_key: string | null;
  password_set: number;
  failed_attempts: number;
  locked_until: string | null;
  created_at: string;
  updated_at: string;
};

class HttpError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

const SESSION_COOKIE = "hn_session";
const JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };
const SECURITY_HEADERS = {
  "cache-control": "no-cache, no-store, must-revalidate",
  "expires": "0",
  "pragma": "no-cache",
  "cross-origin-opener-policy": "same-origin",
  "referrer-policy": "no-referrer",
  "x-content-type-options": "nosniff",
  "x-frame-options": "SAMEORIGIN",
};

export default {
  async fetch(request: Request, env: AppEnv, ctx: ExecutionContext): Promise<Response> {
    const startedAt = Date.now();
    const requestId = crypto.randomUUID();
    let response: Response;
    try {
      response = await route(request, env, ctx);
    } catch (cause) {
      response = handleError(cause, requestId);
    }
    console.log(JSON.stringify({
      event: "request",
      requestId,
      method: request.method,
      path: new URL(request.url).pathname,
      status: response.status,
      durationMs: Date.now() - startedAt,
      environment: env.APP_ENV,
    }));
    return withSecurityHeaders(response, requestId);
  },
} satisfies ExportedHandler<AppEnv>;

async function route(request: Request, env: AppEnv, ctx: ExecutionContext): Promise<Response> {
  const url = new URL(request.url);
  if (url.pathname.startsWith("/api/")) return routeApi(request, env, ctx, url);

  const publicAsset = ["/auth.html", "/auth.js", "/auth.css"].includes(url.pathname);
  if (publicAsset) return env.ASSETS.fetch(request);

  const actor = await sessionActor(request, env);
  if (!actor) {
    if (url.pathname === "/" || request.headers.get("accept")?.includes("text/html")) {
      return env.ASSETS.fetch(new Request(new URL("/auth.html", url), request));
    }
    throw new HttpError(401, "AUTH_REQUIRED", "برای دسترسی دوباره وارد شوید.");
  }

  if (url.pathname === "/") {
    const appUrl = new URL("/index.html", url);
    appUrl.searchParams.set("v", "3.0.0-staging.13");
    return env.ASSETS.fetch(new Request(appUrl, request));
  }
  return env.ASSETS.fetch(request);
}

async function routeApi(request: Request, env: AppEnv, ctx: ExecutionContext, url: URL): Promise<Response> {
  verifyApiRequest(request, url);
  const path = url.pathname.slice(5).replace(/\/+$/, "");

  if (path === "health" && request.method === "GET") {
    return json({ ok: true, environment: env.APP_ENV, version: "3.0.0-staging.13", frontend: "routine-pregnancy-iframe-enabled" });
  }
  if (path === "auth/status" && request.method === "GET") return authStatus(env);
  if (path === "auth/bootstrap" && request.method === "POST") return bootstrap(request, env);
  if (path === "auth/challenge" && request.method === "POST") return createChallenge(request, env);
  if (path === "auth/login" && request.method === "POST") return login(request, env);
  if (path === "auth/activation-info" && request.method === "POST") return activationInfo(request, env);
  if (path === "auth/activate" && request.method === "POST") return activate(request, env);

  const actor = await requireActor(request, env);

  if (path === "me" && request.method === "GET") return me(actor);
  if (path === "admin/export" && request.method === "GET") return exportOrganization(env, actor);
  if (path === "auth/sessions" && request.method === "GET") return listSessions(env, actor);
  if (path === "auth/logout" && request.method === "POST") return logout(env, actor, false);
  if (path === "auth/logout-all" && request.method === "POST") return logout(env, actor, true);
  if (path === "auth/password/change" && request.method === "POST") return changePassword(request, env, actor);

  const sessionMatch = path.match(/^auth\/sessions\/([0-9a-f-]+)$/);
  if (sessionMatch && request.method === "DELETE") return revokeSession(env, actor, sessionMatch[1]);

  if (path === "patients" && request.method === "GET") return listPatients(env, actor, url);
  if (path === "patients" && request.method === "POST") return savePatient(request, env, actor);

  if (path === "users" && request.method === "GET") return listUsers(env, actor);
  if (path === "users" && request.method === "POST") return createUser(request, env, actor, url);
  const userMatch = path.match(/^users\/([0-9a-f-]+)$/);
  if (userMatch && request.method === "PATCH") return updateUser(request, env, actor, userMatch[1]);
  const inviteMatch = path.match(/^users\/([0-9a-f-]+)\/invite$/);
  if (inviteMatch && request.method === "POST") return reinviteUser(env, actor, inviteMatch[1], url);

  if (path === "reports" && request.method === "GET") return listReports(env, actor, url);
  if (path === "reports" && request.method === "POST") return createReport(request, env, actor);
  const reportMatch = path.match(/^reports\/([0-9a-f-]+)$/);
  if (reportMatch && request.method === "GET") return getReport(env, actor, reportMatch[1]);
  if (reportMatch && request.method === "PATCH") return updateReport(request, env, actor, reportMatch[1]);
  if (reportMatch && request.method === "DELETE") return deleteReport(env, actor, reportMatch[1]);

  throw new HttpError(404, "NOT_FOUND", "مسیر درخواستی پیدا نشد.");
}

function verifyApiRequest(request: Request, url: URL): void {
  if (request.method === "GET" || request.method === "HEAD") return;
  if (request.headers.get("x-hn-request") !== "1") {
    throw new HttpError(403, "REQUEST_HEADER_REQUIRED", "درخواست معتبر نیست.");
  }
  const origin = request.headers.get("origin");
  if (origin && origin !== url.origin) throw new HttpError(403, "ORIGIN_MISMATCH", "مبدأ درخواست معتبر نیست.");
}

async function authStatus(env: AppEnv): Promise<Response> {
  const row = await env.DB.prepare("SELECT COUNT(*) AS count FROM users").first<{ count: number }>();
  return json({ initialized: Number(row?.count || 0) > 0, passwordIterations: passwordIterations(env), sessionHours: sessionHours(env) });
}

async function bootstrap(request: Request, env: AppEnv): Promise<Response> {
  const body = await bodyJson(request);
  if (!env.BOOTSTRAP_TOKEN || !safeString(body.bootstrapToken, 512) || body.bootstrapToken !== env.BOOTSTRAP_TOKEN) {
    throw new HttpError(403, "INVALID_BOOTSTRAP_TOKEN", "کد راه‌اندازی معتبر نیست.");
  }
  const count = await env.DB.prepare("SELECT COUNT(*) AS count FROM users").first<{ count: number }>();
  if (Number(count?.count || 0) > 0) throw new HttpError(409, "ALREADY_INITIALIZED", "سامانه قبلاً راه‌اندازی شده است.");

  const organizationName = requiredString(body.organizationName, "نام مرکز", 160);
  const displayName = requiredString(body.displayName, "نام مدیر", 120);
  const email = validEmail(body.email);
  const salt = validEncodedBytes(body.salt, 16, "نمک رمز");
  const derivedKey = validEncodedBytes(body.derivedKey, 32, "کلید رمز");
  const now = nowIso();
  const organizationId = crypto.randomUUID();
  const userId = crypto.randomUUID();
  const slug = `center-${organizationId.slice(0, 8)}`;
  const trialExpiry = new Date(Date.now() + 30 * 86400000).toISOString();

  try {
    await env.DB.batch([
      env.DB.prepare("INSERT INTO system_state (id, initialized_at) VALUES (1, ?)").bind(now),
      env.DB.prepare("INSERT INTO organizations (id, name, slug, subscription_expires_at, created_at) VALUES (?, ?, ?, ?, ?)")
        .bind(organizationId, organizationName, slug, trialExpiry, now),
      env.DB.prepare("INSERT INTO users (id, organization_id, email, display_name, role, password_salt, password_key, password_set, created_at, updated_at) VALUES (?, ?, ?, ?, 'owner', ?, ?, 1, ?, ?)")
        .bind(userId, organizationId, email, displayName, salt, derivedKey, now, now),
      env.DB.prepare("INSERT INTO audit_log (id, organization_id, user_id, action, entity_type, entity_id, created_at) VALUES (?, ?, ?, 'bootstrap', 'organization', ?, ?)")
        .bind(crypto.randomUUID(), organizationId, userId, organizationId, now),
    ]);
  } catch (cause) {
    if (String(cause).includes("UNIQUE")) throw new HttpError(409, "ALREADY_INITIALIZED", "سامانه قبلاً راه‌اندازی شده است.");
    throw cause;
  }
  return json({ ok: true, trialExpiresAt: trialExpiry }, 201);
}

async function createChallenge(request: Request, env: AppEnv): Promise<Response> {
  const body = await bodyJson(request);
  const email = validEmail(body.email);
  const ip = request.headers.get("cf-connecting-ip") || "local";
  const rateKey = await sha256(`challenge:${ip}:${email}`);
  const cutoff = new Date(Date.now() - 10 * 60000).toISOString();
  const rate = await env.DB.prepare("SELECT window_started_at, attempts FROM auth_rate_limits WHERE key_hash = ?")
    .bind(rateKey).first<{ window_started_at: string; attempts: number }>();
  if (rate && rate.window_started_at > cutoff && rate.attempts >= 20) {
    throw new HttpError(429, "RATE_LIMITED", "تعداد تلاش ورود زیاد است؛ چند دقیقه بعد دوباره امتحان کنید.");
  }
  await env.DB.prepare("INSERT INTO auth_rate_limits (key_hash, window_started_at, attempts) VALUES (?, ?, 1) ON CONFLICT(key_hash) DO UPDATE SET window_started_at = CASE WHEN window_started_at <= ? THEN excluded.window_started_at ELSE window_started_at END, attempts = CASE WHEN window_started_at <= ? THEN 1 ELSE attempts + 1 END")
    .bind(rateKey, nowIso(), cutoff, cutoff).run();
  const user = await env.DB.prepare("SELECT * FROM users WHERE email = ? LIMIT 1").bind(email).first<UserRow>();
  const challengeId = crypto.randomUUID();
  const nonce = randomBase64Url(32);
  const now = nowIso();
  const expiresAt = new Date(Date.now() + 5 * 60000).toISOString();
  await env.DB.prepare("INSERT INTO login_challenges (id, user_id, nonce, expires_at, created_at) VALUES (?, ?, ?, ?, ?)")
    .bind(challengeId, user?.id ?? null, nonce, expiresAt, now).run();
  await cleanupChallenges(env);
  return json({
    challengeId,
    nonce,
    salt: user?.password_salt || randomBase64Url(16),
    passwordIterations: passwordIterations(env),
    expiresAt,
  });
}

async function login(request: Request, env: AppEnv): Promise<Response> {
  const body = await bodyJson(request);
  const challengeId = requiredString(body.challengeId, "شناسه چالش", 64);
  const proof = validEncodedBytes(body.proof, 32, "امضای ورود");
  const now = nowIso();
  const challenge = await env.DB.prepare(
    "SELECT c.id, c.user_id, c.nonce, c.expires_at, c.used_at, u.password_key, u.active, u.password_set, u.locked_until FROM login_challenges c LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?",
  ).bind(challengeId).first<{
    id: string; user_id: string | null; nonce: string; expires_at: string; used_at: string | null;
    password_key: string | null; active: number | null; password_set: number | null; locked_until: string | null;
  }>();
  if (!challenge || challenge.used_at || challenge.expires_at <= now) return invalidLogin();
  await env.DB.prepare("UPDATE login_challenges SET used_at = ? WHERE id = ? AND used_at IS NULL").bind(now, challengeId).run();
  if (!challenge.user_id || !challenge.password_key || challenge.active !== 1 || challenge.password_set !== 1) return invalidLogin();
  if (challenge.locked_until && challenge.locked_until > now) {
    throw new HttpError(429, "ACCOUNT_LOCKED", "به‌دلیل چند ورود ناموفق، حساب موقتاً قفل شده است.");
  }

  const valid = await verifyPasswordProof(challenge.password_key, proof, challengeId, challenge.nonce);
  if (!valid) {
    const lockedUntil = new Date(Date.now() + 15 * 60000).toISOString();
    await env.DB.prepare("UPDATE users SET failed_attempts = CASE WHEN locked_until IS NOT NULL AND locked_until <= ? THEN 1 ELSE failed_attempts + 1 END, locked_until = CASE WHEN (CASE WHEN locked_until IS NOT NULL AND locked_until <= ? THEN 1 ELSE failed_attempts + 1 END) >= 5 THEN ? ELSE locked_until END, updated_at = ? WHERE id = ?")
      .bind(now, now, lockedUntil, now, challenge.user_id).run();
    return invalidLogin();
  }

  const rawToken = randomBase64Url(32);
  const tokenHash = await sha256(rawToken);
  const sessionId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + sessionHours(env) * 3600000).toISOString();
  const deviceLabel = deviceName(request.headers.get("user-agent") || "");
  await env.DB.batch([
    env.DB.prepare("INSERT INTO sessions (id, user_id, token_hash, device_label, created_at, last_seen_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .bind(sessionId, challenge.user_id, tokenHash, deviceLabel, now, now, expiresAt),
    env.DB.prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?").bind(now, challenge.user_id),
  ]);
  return json({ ok: true, expiresAt }, 200, { "set-cookie": sessionCookie(rawToken, sessionHours(env)) });
}

function invalidLogin(): never {
  throw new HttpError(401, "INVALID_CREDENTIALS", "ایمیل یا رمز عبور صحیح نیست.");
}

async function activationInfo(request: Request, env: AppEnv): Promise<Response> {
  const body = await bodyJson(request);
  const token = requiredString(body.token, "توکن فعال‌سازی", 256);
  const row = await activationRow(env, token);
  if (!row) throw new HttpError(404, "INVALID_ACTIVATION", "لینک فعال‌سازی نامعتبر یا منقضی شده است.");
  return json({ email: row.email, displayName: row.display_name, organizationName: row.organization_name, expiresAt: row.expires_at, passwordIterations: passwordIterations(env) });
}

async function activate(request: Request, env: AppEnv): Promise<Response> {
  const body = await bodyJson(request);
  const token = requiredString(body.token, "توکن فعال‌سازی", 256);
  const salt = validEncodedBytes(body.salt, 16, "نمک رمز");
  const derivedKey = validEncodedBytes(body.derivedKey, 32, "کلید رمز");
  const row = await activationRow(env, token);
  if (!row) throw new HttpError(404, "INVALID_ACTIVATION", "لینک فعال‌سازی نامعتبر یا منقضی شده است.");
  const now = nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE users SET password_salt = ?, password_key = ?, password_set = 1, failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?")
      .bind(salt, derivedKey, now, row.user_id),
    env.DB.prepare("UPDATE activation_tokens SET used_at = ? WHERE id = ? AND used_at IS NULL").bind(now, row.id),
    env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL").bind(now, row.user_id),
  ]);
  return json({ ok: true });
}

async function activationRow(env: AppEnv, token: string): Promise<{
  id: string; user_id: string; email: string; display_name: string; organization_name: string; expires_at: string;
} | null> {
  const tokenHash = await sha256(token);
  return env.DB.prepare("SELECT a.id, a.user_id, a.expires_at, u.email, u.display_name, o.name AS organization_name FROM activation_tokens a JOIN users u ON u.id = a.user_id JOIN organizations o ON o.id = u.organization_id WHERE a.token_hash = ? AND a.used_at IS NULL AND a.expires_at > ? AND u.active = 1")
    .bind(tokenHash, nowIso()).first();
}

async function requireActor(request: Request, env: AppEnv): Promise<Actor> {
  const actor = await sessionActor(request, env);
  if (!actor) throw new HttpError(401, "AUTH_REQUIRED", "نشست ورود منقضی شده است؛ دوباره وارد شوید.");
  return actor;
}

async function sessionActor(request: Request, env: AppEnv): Promise<Actor | null> {
  const rawToken = readCookie(request.headers.get("cookie") || "", SESSION_COOKIE);
  if (!rawToken) return null;
  const tokenHash = await sha256(rawToken);
  const now = nowIso();
  const row = await env.DB.prepare(
    "SELECT s.id AS session_id, s.last_seen_at, u.id, u.organization_id, u.email, u.display_name, u.role, o.name AS organization_name, o.status AS organization_status, o.subscription_expires_at FROM sessions s JOIN users u ON u.id = s.user_id JOIN organizations o ON o.id = u.organization_id WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.active = 1",
  ).bind(tokenHash, now).first<{
    session_id: string; id: string; organization_id: string; email: string; display_name: string; role: Role;
    organization_name: string; organization_status: "active" | "suspended"; subscription_expires_at: string | null; last_seen_at: string;
  }>();
  if (!row) return null;
  const touchCutoff = new Date(Date.now() - 5 * 60000).toISOString();
  if (row.last_seen_at < touchCutoff) {
    await env.DB.prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").bind(now, row.session_id).run();
  }
  return {
    sessionId: row.session_id,
    id: row.id,
    organizationId: row.organization_id,
    email: row.email,
    displayName: row.display_name,
    role: row.role,
    organizationName: row.organization_name,
    organizationStatus: row.organization_status,
    subscriptionExpiresAt: row.subscription_expires_at,
  };
}

function me(actor: Actor): Response {
  return json({
    user: { id: actor.id, email: actor.email, displayName: actor.displayName, role: actor.role },
    organization: {
      id: actor.organizationId,
      name: actor.organizationName,
      status: actor.organizationStatus,
      subscriptionExpiresAt: actor.subscriptionExpiresAt,
      subscriptionActive: subscriptionActive(actor),
      unlimitedAccess: actor.role === "owner",
    },
  });
}

async function exportOrganization(env: AppEnv, actor: Actor): Promise<Response> {
  assertRole(actor, ["owner"]);
  const [users, patients, reports, revisions] = await env.DB.batch([
    env.DB.prepare("SELECT id, email, display_name, role, active, password_set, created_at, updated_at FROM users WHERE organization_id = ? ORDER BY created_at").bind(actor.organizationId),
    env.DB.prepare("SELECT id, patient_code, full_name, birth_date, sex, phone, clinic, created_at, updated_at FROM patients WHERE organization_id = ? ORDER BY created_at").bind(actor.organizationId),
    env.DB.prepare("SELECT id, owner_user_id, patient_id, patient_code, patient_name, exam_title, report_text, status, client_id, created_at, updated_at, deleted_at FROM reports WHERE organization_id = ? ORDER BY created_at").bind(actor.organizationId),
    env.DB.prepare("SELECT rr.id, rr.report_id, rr.edited_by, rr.report_text, rr.status, rr.created_at FROM report_revisions rr JOIN reports r ON r.id = rr.report_id WHERE r.organization_id = ? ORDER BY rr.created_at").bind(actor.organizationId),
  ]);
  await audit(env, actor, "organization_exported", "organization", actor.organizationId);
  return json({
    schemaVersion: 1,
    exportedAt: nowIso(),
    organization: { id: actor.organizationId, name: actor.organizationName },
    users: (users.results as Record<string, unknown>[]).map(mapUser),
    patients: (patients.results as Record<string, unknown>[]).map(mapPatient),
    reports: (reports.results as Record<string, unknown>[]).map((row) => ({ ...mapReport(row), patientId: row.patient_id, deletedAt: row.deleted_at })),
    reportRevisions: (revisions.results as Record<string, unknown>[]).map((row) => ({ id: row.id, reportId: row.report_id, editedBy: row.edited_by, reportText: row.report_text, status: row.status, createdAt: row.created_at })),
  }, 200, { "content-disposition": `attachment; filename="hn-radiology-backup-${nowIso().slice(0, 10)}.json"` });
}

async function listSessions(env: AppEnv, actor: Actor): Promise<Response> {
  const result = await env.DB.prepare("SELECT id, device_label, created_at, last_seen_at, expires_at FROM sessions WHERE user_id = ? AND revoked_at IS NULL AND expires_at > ? ORDER BY last_seen_at DESC")
    .bind(actor.id, nowIso()).all<{ id: string; device_label: string; created_at: string; last_seen_at: string; expires_at: string }>();
  return json({ sessions: result.results.map((row) => ({ id: row.id, deviceLabel: row.device_label, createdAt: row.created_at, lastSeenAt: row.last_seen_at, expiresAt: row.expires_at, current: row.id === actor.sessionId })) });
}

async function revokeSession(env: AppEnv, actor: Actor, sessionId: string): Promise<Response> {
  const now = nowIso();
  const result = await env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE id = ? AND user_id = ? AND revoked_at IS NULL").bind(now, sessionId, actor.id).run();
  if (!result.meta.changes) throw new HttpError(404, "SESSION_NOT_FOUND", "نشست پیدا نشد.");
  return json({ ok: true });
}

async function logout(env: AppEnv, actor: Actor, all: boolean): Promise<Response> {
  const now = nowIso();
  if (all) await env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL").bind(now, actor.id).run();
  else await env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE id = ?").bind(now, actor.sessionId).run();
  return json({ ok: true }, 200, { "set-cookie": clearSessionCookie() });
}

async function changePassword(request: Request, env: AppEnv, actor: Actor): Promise<Response> {
  assertSubscription(actor);
  const body = await bodyJson(request);
  const challengeId = requiredString(body.challengeId, "شناسه چالش", 64);
  const proof = validEncodedBytes(body.proof, 32, "امضای رمز", true);
  const salt = validEncodedBytes(body.salt, 16, "نمک رمز");
  const derivedKey = validEncodedBytes(body.derivedKey, 32, "کلید رمز");
  const now = nowIso();
  const row = await env.DB.prepare("SELECT c.id, c.user_id, c.nonce, c.expires_at, c.used_at, u.password_key FROM login_challenges c JOIN users u ON u.id = c.user_id WHERE c.id = ? AND c.user_id = ?")
    .bind(challengeId, actor.id).first<{ id: string; user_id: string; nonce: string; expires_at: string; used_at: string | null; password_key: string }>();
  if (!row || row.used_at || row.expires_at <= now || !(await verifyPasswordProof(row.password_key, proof, row.id, row.nonce))) {
    throw new HttpError(401, "CURRENT_PASSWORD_INVALID", "رمز فعلی صحیح نیست.");
  }
  await env.DB.batch([
    env.DB.prepare("UPDATE login_challenges SET used_at = ? WHERE id = ?").bind(now, row.id),
    env.DB.prepare("UPDATE users SET password_salt = ?, password_key = ?, updated_at = ? WHERE id = ?").bind(salt, derivedKey, now, actor.id),
    env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND id <> ? AND revoked_at IS NULL").bind(now, actor.id, actor.sessionId),
  ]);
  await audit(env, actor, "password_changed", "user", actor.id);
  return json({ ok: true });
}

async function listPatients(env: AppEnv, actor: Actor, url: URL): Promise<Response> {
  const limit = boundedLimit(url.searchParams.get("limit"), 200, 500);
  const q = (url.searchParams.get("q") || "").trim().slice(0, 100);
  const pattern = `%${escapeLike(q)}%`;
  const result = await env.DB.prepare("SELECT id, patient_code, full_name, birth_date, sex, phone, clinic, created_at, updated_at FROM patients WHERE organization_id = ? AND (? = '' OR patient_code LIKE ? ESCAPE '\\' OR full_name LIKE ? ESCAPE '\\') ORDER BY updated_at DESC LIMIT ?")
    .bind(actor.organizationId, q, pattern, pattern, limit).all();
  return json({ patients: result.results.map(mapPatient) });
}

async function savePatient(request: Request, env: AppEnv, actor: Actor): Promise<Response> {
  assertRole(actor, ["owner", "radiologist", "secretary"]);
  assertSubscription(actor);
  const body = await bodyJson(request);
  const patientCode = patientCodeValue(body.patientCode);
  const fullName = safeString(body.fullName, 160);
  const birthDate = safeString(body.birthDate, 20);
  const sex = ["", "female", "male", "other"].includes(body.sex) ? body.sex : "";
  const phone = safeString(body.phone, 40);
  const clinic = safeString(body.clinic, 160);
  const now = nowIso();
  const id = crypto.randomUUID();
  await env.DB.prepare("INSERT INTO patients (id, organization_id, patient_code, full_name, birth_date, sex, phone, clinic, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(organization_id, patient_code) DO UPDATE SET full_name = excluded.full_name, birth_date = excluded.birth_date, sex = excluded.sex, phone = excluded.phone, clinic = excluded.clinic, updated_at = excluded.updated_at")
    .bind(id, actor.organizationId, patientCode, fullName, birthDate, sex, phone, clinic, actor.id, now, now).run();
  const row = await env.DB.prepare("SELECT id, patient_code, full_name, birth_date, sex, phone, clinic, created_at, updated_at FROM patients WHERE organization_id = ? AND patient_code = ?").bind(actor.organizationId, patientCode).first();
  await audit(env, actor, "patient_saved", "patient", String((row as { id?: string })?.id || id));
  return json({ patient: mapPatient(row || {}) }, 201);
}

function mapPatient(row: Record<string, unknown>): Record<string, unknown> {
  return { id: row.id, patientCode: row.patient_code, fullName: row.full_name, birthDate: row.birth_date, sex: row.sex, phone: row.phone, clinic: row.clinic, createdAt: row.created_at, updatedAt: row.updated_at };
}

async function listUsers(env: AppEnv, actor: Actor): Promise<Response> {
  assertRole(actor, ["owner"]);
  const result = await env.DB.prepare("SELECT id, email, display_name, role, active, password_set, created_at, updated_at FROM users WHERE organization_id = ? ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END, display_name")
    .bind(actor.organizationId).all();
  return json({ users: result.results.map(mapUser) });
}

async function createUser(request: Request, env: AppEnv, actor: Actor, url: URL): Promise<Response> {
  assertRole(actor, ["owner"]);
  assertSubscription(actor);
  const body = await bodyJson(request);
  const email = validEmail(body.email);
  const displayName = requiredString(body.displayName, "نام عضو", 120);
  const role = validAssignableRole(body.role);
  const userId = crypto.randomUUID();
  const now = nowIso();
  try {
    await env.DB.prepare("INSERT INTO users (id, organization_id, email, display_name, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .bind(userId, actor.organizationId, email, displayName, role, now, now).run();
  } catch (cause) {
    if (String(cause).includes("UNIQUE")) throw new HttpError(409, "EMAIL_EXISTS", "این ایمیل قبلاً ثبت شده است.");
    throw cause;
  }
  const invitation = await newInvitation(env, actor, userId, url);
  await audit(env, actor, "user_created", "user", userId, { role });
  return json({ userId, ...invitation }, 201);
}

async function updateUser(request: Request, env: AppEnv, actor: Actor, userId: string): Promise<Response> {
  assertRole(actor, ["owner"]);
  assertSubscription(actor);
  if (userId === actor.id) throw new HttpError(400, "CANNOT_DISABLE_SELF", "مدیر نمی‌تواند حساب خودش را غیرفعال کند.");
  const body = await bodyJson(request);
  if (typeof body.active !== "boolean") throw new HttpError(400, "INVALID_ACTIVE", "وضعیت حساب معتبر نیست.");
  const now = nowIso();
  const result = await env.DB.prepare("UPDATE users SET active = ?, updated_at = ? WHERE id = ? AND organization_id = ? AND role <> 'owner'")
    .bind(body.active ? 1 : 0, now, userId, actor.organizationId).run();
  if (!result.meta.changes) throw new HttpError(404, "USER_NOT_FOUND", "عضو پیدا نشد.");
  if (!body.active) await env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL").bind(now, userId).run();
  await audit(env, actor, body.active ? "user_enabled" : "user_disabled", "user", userId);
  return json({ ok: true });
}

async function reinviteUser(env: AppEnv, actor: Actor, userId: string, url: URL): Promise<Response> {
  assertRole(actor, ["owner"]);
  assertSubscription(actor);
  const user = await env.DB.prepare("SELECT id FROM users WHERE id = ? AND organization_id = ? AND role <> 'owner'").bind(userId, actor.organizationId).first();
  if (!user) throw new HttpError(404, "USER_NOT_FOUND", "عضو پیدا نشد.");
  const now = nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE users SET active = 1, password_salt = NULL, password_key = NULL, password_set = 0, updated_at = ? WHERE id = ?").bind(now, userId),
    env.DB.prepare("UPDATE activation_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL").bind(now, userId),
    env.DB.prepare("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL").bind(now, userId),
  ]);
  const invitation = await newInvitation(env, actor, userId, url);
  await audit(env, actor, "user_reinvited", "user", userId);
  return json(invitation);
}

async function newInvitation(env: AppEnv, actor: Actor, userId: string, url: URL): Promise<{ activationUrl: string; activationExpiresAt: string }> {
  const rawToken = randomBase64Url(32);
  const tokenHash = await sha256(rawToken);
  const now = nowIso();
  const expiresAt = new Date(Date.now() + 72 * 3600000).toISOString();
  await env.DB.prepare("INSERT INTO activation_tokens (id, user_id, token_hash, expires_at, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)")
    .bind(crypto.randomUUID(), userId, tokenHash, expiresAt, actor.id, now).run();
  return { activationUrl: `${url.origin}/#activate=${rawToken}`, activationExpiresAt: expiresAt };
}

function mapUser(row: Record<string, unknown>): Record<string, unknown> {
  return { id: row.id, email: row.email, displayName: row.display_name, role: row.role, active: row.active === 1, passwordSet: row.password_set === 1, createdAt: row.created_at, updatedAt: row.updated_at };
}

async function listReports(env: AppEnv, actor: Actor, url: URL): Promise<Response> {
  assertRole(actor, ["owner", "radiologist", "viewer"]);
  const limit = boundedLimit(url.searchParams.get("limit"), 250, 500);
  const ownerClause = actor.role === "radiologist" ? "AND owner_user_id = ?" : "";
  const params: unknown[] = [actor.organizationId];
  if (actor.role === "radiologist") params.push(actor.id);
  params.push(limit);
  const result = await env.DB.prepare(`SELECT id, owner_user_id, patient_code, patient_name, exam_title, report_text, status, client_id, created_at, updated_at FROM reports WHERE organization_id = ? ${ownerClause} AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT ?`)
    .bind(...params).all();
  return json({ reports: result.results.map(mapReport) });
}

async function createReport(request: Request, env: AppEnv, actor: Actor): Promise<Response> {
  assertRole(actor, ["owner", "radiologist"]);
  assertSubscription(actor);
  const body = await bodyJson(request);
  const patientCode = patientCodeValue(body.patientCode);
  const patientName = safeString(body.patientName, 160);
  const examTitle = requiredString(body.examTitle, "عنوان بررسی", 200);
  const reportText = requiredString(body.reportText, "متن گزارش", 200000);
  const status = validReportStatus(body.status);
  const clientId = safeString(body.clientId, 120) || null;
  const now = nowIso();
  const createdAt = validClientDate(body.createdAt) || now;
  const existing = clientId ? await env.DB.prepare("SELECT * FROM reports WHERE organization_id = ? AND owner_user_id = ? AND client_id = ?")
    .bind(actor.organizationId, actor.id, clientId).first() : null;
  if (existing) return json({ report: mapReport(existing as Record<string, unknown>), duplicate: true });
  const patientId = crypto.randomUUID();
  const reportId = crypto.randomUUID();
  await env.DB.batch([
    env.DB.prepare("INSERT OR IGNORE INTO patients (id, organization_id, patient_code, full_name, birth_date, sex, phone, clinic, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, '', '', '', '', ?, ?, ?)")
      .bind(patientId, actor.organizationId, patientCode, patientName, actor.id, now, now),
    env.DB.prepare("UPDATE patients SET full_name = CASE WHEN ? <> '' THEN ? ELSE full_name END, updated_at = ? WHERE organization_id = ? AND patient_code = ?")
      .bind(patientName, patientName, now, actor.organizationId, patientCode),
    env.DB.prepare("INSERT INTO reports (id, organization_id, owner_user_id, patient_id, patient_code, patient_name, exam_title, report_text, status, client_id, created_by, updated_by, created_at, updated_at) VALUES (?, ?, ?, (SELECT id FROM patients WHERE organization_id = ? AND patient_code = ?), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
      .bind(reportId, actor.organizationId, actor.id, actor.organizationId, patientCode, patientCode, patientName, examTitle, reportText, status, clientId, actor.id, actor.id, createdAt, now),
    env.DB.prepare("INSERT INTO report_revisions (id, report_id, edited_by, report_text, status, created_at) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), reportId, actor.id, reportText, status, now),
  ]);
  await audit(env, actor, "report_created", "report", reportId);
  const row = await env.DB.prepare("SELECT * FROM reports WHERE id = ?").bind(reportId).first();
  return json({ report: mapReport(row as Record<string, unknown>) }, 201);
}

async function getReport(env: AppEnv, actor: Actor, reportId: string): Promise<Response> {
  assertRole(actor, ["owner", "radiologist", "viewer"]);
  const row = await scopedReport(env, actor, reportId);
  return json({ report: mapReport(row) });
}

async function updateReport(request: Request, env: AppEnv, actor: Actor, reportId: string): Promise<Response> {
  assertRole(actor, ["owner", "radiologist"]);
  assertSubscription(actor);
  const current = await scopedReport(env, actor, reportId, true);
  const body = await bodyJson(request);
  const reportText = body.reportText === undefined ? String(current.report_text) : requiredString(body.reportText, "متن گزارش", 200000);
  const status = body.status === undefined ? String(current.status) : validReportStatus(body.status);
  const examTitle = body.examTitle === undefined ? String(current.exam_title) : requiredString(body.examTitle, "عنوان بررسی", 200);
  const now = nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE reports SET report_text = ?, status = ?, exam_title = ?, updated_by = ?, updated_at = ? WHERE id = ?")
      .bind(reportText, status, examTitle, actor.id, now, reportId),
    env.DB.prepare("INSERT INTO report_revisions (id, report_id, edited_by, report_text, status, created_at) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(crypto.randomUUID(), reportId, actor.id, reportText, status, now),
  ]);
  await audit(env, actor, "report_updated", "report", reportId);
  const row = await env.DB.prepare("SELECT * FROM reports WHERE id = ?").bind(reportId).first();
  return json({ report: mapReport(row as Record<string, unknown>) });
}

async function deleteReport(env: AppEnv, actor: Actor, reportId: string): Promise<Response> {
  assertRole(actor, ["owner", "radiologist"]);
  assertSubscription(actor);
  await scopedReport(env, actor, reportId, true);
  const now = nowIso();
  await env.DB.prepare("UPDATE reports SET deleted_at = ?, updated_by = ?, updated_at = ? WHERE id = ?").bind(now, actor.id, now, reportId).run();
  await audit(env, actor, "report_deleted", "report", reportId);
  return json({ ok: true });
}

async function scopedReport(env: AppEnv, actor: Actor, reportId: string, writable = false): Promise<Record<string, unknown>> {
  if (writable && actor.role === "viewer") throw new HttpError(403, "ROLE_FORBIDDEN", "این حساب اجازه تغییر گزارش را ندارد.");
  const ownerClause = actor.role === "radiologist" ? "AND owner_user_id = ?" : "";
  const params: unknown[] = [reportId, actor.organizationId];
  if (actor.role === "radiologist") params.push(actor.id);
  const row = await env.DB.prepare(`SELECT * FROM reports WHERE id = ? AND organization_id = ? ${ownerClause} AND deleted_at IS NULL`).bind(...params).first();
  if (!row) throw new HttpError(404, "REPORT_NOT_FOUND", "گزارش پیدا نشد.");
  return row as Record<string, unknown>;
}

function mapReport(row: Record<string, unknown>): Record<string, unknown> {
  return { id: row.id, ownerUserId: row.owner_user_id, patientCode: row.patient_code, patientName: row.patient_name, examTitle: row.exam_title, reportText: row.report_text, status: row.status, clientId: row.client_id, createdAt: row.created_at, updatedAt: row.updated_at };
}

async function audit(env: AppEnv, actor: Actor, action: string, entityType: string, entityId: string, metadata: Record<string, unknown> = {}): Promise<void> {
  await env.DB.prepare("INSERT INTO audit_log (id, organization_id, user_id, action, entity_type, entity_id, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
    .bind(crypto.randomUUID(), actor.organizationId, actor.id, action, entityType, entityId, JSON.stringify(metadata), nowIso()).run();
}

function assertRole(actor: Actor, roles: Role[]): void {
  if (!roles.includes(actor.role)) throw new HttpError(403, "ROLE_FORBIDDEN", "نقش این حساب اجازه انجام این کار را ندارد.");
}

function assertSubscription(actor: Actor): void {
  if (!subscriptionActive(actor)) throw new HttpError(402, "SUBSCRIPTION_INACTIVE", "اشتراک مرکز فعال نیست؛ برای تمدید با پشتیبانی تماس بگیرید.");
}

function subscriptionActive(actor: Actor): boolean {
  return actor.role === "owner" || (actor.organizationStatus === "active" && (!actor.subscriptionExpiresAt || actor.subscriptionExpiresAt > nowIso()));
}

function validAssignableRole(value: unknown): Exclude<Role, "owner"> {
  if (value === "radiologist" || value === "secretary" || value === "viewer") return value;
  throw new HttpError(400, "INVALID_ROLE", "نقش انتخاب‌شده معتبر نیست.");
}

function validReportStatus(value: unknown): "draft" | "final" {
  if (value === undefined || value === "final") return "final";
  if (value === "draft") return "draft";
  throw new HttpError(400, "INVALID_STATUS", "وضعیت گزارش معتبر نیست.");
}

function patientCodeValue(value: unknown): string {
  const code = normalizeDigits(String(value ?? "").trim());
  if (!/^\d{6}$/.test(code)) throw new HttpError(400, "INVALID_PATIENT_CODE", "شناسه بیمار باید دقیقاً شش رقم باشد.");
  return code;
}

function normalizeDigits(value: string): string {
  const persian = "۰۱۲۳۴۵۶۷۸۹";
  const arabic = "٠١٢٣٤٥٦٧٨٩";
  return value
    .replace(/[۰-۹]/g, (digit) => String(persian.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String(arabic.indexOf(digit)));
}

function validEmail(value: unknown): string {
  const email = String(value ?? "").trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, "INVALID_EMAIL", "ایمیل معتبر وارد کنید.");
  return email;
}

function safeString(value: unknown, max: number): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function requiredString(value: unknown, label: string, max: number): string {
  const result = safeString(value, max);
  if (!result) throw new HttpError(400, "REQUIRED_FIELD", `${label} الزامی است.`);
  return result;
}

function validEncodedBytes(value: unknown, length: number, label: string, returnNormalized = false): string {
  const encoded = requiredString(value, label, 512);
  try {
    const bytes = base64UrlBytes(encoded);
    if (bytes.byteLength !== length) throw new Error("length");
    return returnNormalized ? toBase64Url(bytes) : encoded;
  } catch {
    throw new HttpError(400, "INVALID_CRYPTO_VALUE", `${label} معتبر نیست.`);
  }
}

function validClientDate(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return null;
  const min = Date.now() - 10 * 365 * 86400000;
  const max = Date.now() + 86400000;
  return date.getTime() >= min && date.getTime() <= max ? date.toISOString() : null;
}

async function bodyJson(request: Request): Promise<Record<string, any>> {
  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) {
    throw new HttpError(415, "JSON_REQUIRED", "بدنه درخواست باید JSON باشد.");
  }
  try {
    const value = await request.json();
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("object required");
    return value as Record<string, any>;
  } catch {
    throw new HttpError(400, "INVALID_JSON", "بدنه درخواست معتبر نیست.");
  }
}

async function verifyPasswordProof(storedKey: string, proof: string, challengeId: string, nonce: string): Promise<boolean> {
  try {
    const key = await crypto.subtle.importKey("raw", base64UrlBytes(storedKey) as BufferSource, { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    const data = new TextEncoder().encode(`hn-login-proof-v1:${challengeId}:${nonce}`);
    return crypto.subtle.verify("HMAC", key, base64UrlBytes(proof) as BufferSource, data);
  } catch {
    return false;
  }
}

async function sha256(value: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return toBase64Url(new Uint8Array(digest));
}

function randomBase64Url(length: number): string {
  return toBase64Url(crypto.getRandomValues(new Uint8Array(length)));
}

function base64UrlBytes(value: string): Uint8Array {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "="));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function toBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function readCookie(header: string, name: string): string | null {
  for (const item of header.split(";")) {
    const [key, ...value] = item.trim().split("=");
    if (key === name) return decodeURIComponent(value.join("="));
  }
  return null;
}

function sessionCookie(token: string, hours: number): string {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${Math.floor(hours * 3600)}`;
}

function clearSessionCookie(): string {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

function deviceName(userAgent: string): string {
  const browser = /Edg\//.test(userAgent) ? "Edge" : /Firefox\//.test(userAgent) ? "Firefox" : /Chrome\//.test(userAgent) ? "Chrome" : /Safari\//.test(userAgent) ? "Safari" : "مرورگر";
  const device = /Mobile|Android|iPhone|iPad/.test(userAgent) ? "موبایل/تبلت" : "رایانه";
  return `${browser} روی ${device}`;
}

function boundedLimit(value: string | null, fallback: number, max: number): number {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? Math.min(parsed, max) : fallback;
}

function escapeLike(value: string): string {
  return value.replace(/[\\%_]/g, "\\$&");
}

function passwordIterations(env: AppEnv): number {
  const value = Number(env.PASSWORD_ITERATIONS);
  return Number.isInteger(value) && value >= 310000 && value <= 2000000 ? value : 600000;
}

function sessionHours(env: AppEnv): number {
  const value = Number(env.SESSION_HOURS);
  return Number.isFinite(value) && value >= 1 && value <= 168 ? value : 12;
}

function nowIso(): string {
  return new Date().toISOString();
}

function json(data: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...headers } });
}

function handleError(cause: unknown, requestId: string): Response {
  if (cause instanceof HttpError) return json({ code: cause.code, message: cause.message, requestId }, cause.status);
  console.error(JSON.stringify({ event: "unhandled_error", requestId, error: cause instanceof Error ? cause.message : String(cause) }));
  return json({ code: "INTERNAL_ERROR", message: "خطای داخلی رخ داد. شناسه پیگیری را برای پشتیبانی بفرستید.", requestId }, 500);
}

function withSecurityHeaders(response: Response, requestId: string): Response {
  const headers = new Headers(response.headers);
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) headers.set(key, value);
  headers.set("x-request-id", requestId);
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

async function cleanupChallenges(env: AppEnv): Promise<void> {
  const cutoff = new Date(Date.now() - 24 * 3600000).toISOString();
  await env.DB.batch([
    env.DB.prepare("DELETE FROM login_challenges WHERE created_at < ?").bind(cutoff),
    env.DB.prepare("DELETE FROM auth_rate_limits WHERE window_started_at < ?").bind(cutoff),
  ]);
}
