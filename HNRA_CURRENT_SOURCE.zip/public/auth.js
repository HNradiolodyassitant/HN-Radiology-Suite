(() => {
  "use strict";
  const card = document.getElementById("auth-card");
  const toastNode = document.getElementById("toast");
  let settings = { passwordIterations: 600000, sessionHours: 12 };

  async function api(path, options = {}) {
    const init = { credentials: "same-origin", ...options };
    init.headers = { "x-hn-request": "1", ...(init.headers || {}) };
    if (init.body && typeof init.body !== "string") {
      init.headers["content-type"] = "application/json";
      init.body = JSON.stringify(init.body);
    }
    const response = await fetch(`/api/${path}`, init);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || `خطای ${response.status}`);
      error.code = data.code;
      throw error;
    }
    return data;
  }

  function renderLogin() {
    card.innerHTML = `
      <h2>ورود به حساب</h2>
      <p>با حساب اختصاصی مرکز وارد شوید.</p>
      <form id="login-form">
        <label>ایمیل</label><input name="email" type="email" autocomplete="username" inputmode="email" dir="ltr" required>
        <label>رمز عبور</label><input name="password" type="password" autocomplete="current-password" minlength="12" maxlength="128" dir="ltr" required>
        <button type="submit">ورود امن</button>
      </form>`;
    card.querySelector("form").addEventListener("submit", login);
  }

  function renderBootstrap() {
    card.innerHTML = `
      <h2>راه‌اندازی مرکز</h2>
      <p>اولین حساب مدیر را برای محیط Staging بسازید.</p>
      <div class="note danger-note">کد راه‌اندازی همان رازی است که هنگام نصب Worker تنظیم می‌شود.</div>
      <form id="bootstrap-form">
        <div class="field-row"><div><label>نام مرکز</label><input name="organizationName" maxlength="160" required></div><div><label>نام مدیر</label><input name="displayName" maxlength="120" required></div></div>
        <label>ایمیل مدیر</label><input name="email" type="email" autocomplete="username" dir="ltr" required>
        <label>رمز عبور</label><input name="password" type="password" autocomplete="new-password" minlength="12" maxlength="128" dir="ltr" required><div class="password-hint">حداقل ۱۲ نویسه؛ بهتر است شامل حروف، عدد و نشانه باشد.</div>
        <label>کد راه‌اندازی</label><input name="bootstrapToken" type="password" autocomplete="off" dir="ltr" required>
        <button type="submit">ساخت حساب مدیر</button>
      </form>`;
    card.querySelector("form").addEventListener("submit", bootstrap);
  }

  async function renderActivation(token) {
    try {
      const info = await api("auth/activation-info", { method: "POST", body: { token } });
      settings.passwordIterations = info.passwordIterations;
      card.innerHTML = `
        <h2>فعال‌سازی حساب</h2>
        <p>${escapeHtml(info.displayName)}، حساب شما در «${escapeHtml(info.organizationName)}» آماده است.</p>
        <div class="note">ایمیل ورود: <span dir="ltr">${escapeHtml(info.email)}</span></div>
        <form id="activation-form">
          <label>رمز عبور جدید</label><input name="password" type="password" autocomplete="new-password" minlength="12" maxlength="128" dir="ltr" required>
          <label>تکرار رمز عبور</label><input name="confirm" type="password" autocomplete="new-password" minlength="12" maxlength="128" dir="ltr" required>
          <div class="password-hint">حداقل ۱۲ نویسه انتخاب کنید و آن را فقط نزد خودتان نگه دارید.</div>
          <button type="submit">فعال‌سازی و رفتن به ورود</button>
        </form>`;
      card.querySelector("form").addEventListener("submit", (event) => activate(event, token));
    } catch (error) {
      card.innerHTML = `<h2>لینک قابل استفاده نیست</h2><p>${escapeHtml(error.message)}</p><button id="back-login" type="button">بازگشت به ورود</button>`;
      card.querySelector("button").addEventListener("click", () => { history.replaceState(null, "", "/"); renderLogin(); });
    }
  }

  async function login(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button");
    button.disabled = true;
    try {
      const email = form.elements.email.value.trim().toLowerCase();
      const challenge = await api("auth/challenge", { method: "POST", body: { email } });
      const key = await derivePasswordKey(form.elements.password.value, fromBase64Url(challenge.salt), challenge.passwordIterations);
      const proof = await passwordProof(key, challenge.challengeId, challenge.nonce);
      await api("auth/login", { method: "POST", body: { challengeId: challenge.challengeId, proof: toBase64Url(proof) } });
      location.replace("/");
    } catch (error) {
      showToast(error.message, true);
      button.disabled = false;
    }
  }

  async function bootstrap(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button");
    button.disabled = true;
    try {
      const password = form.elements.password.value;
      if (password.length < 12) throw new Error("رمز عبور باید حداقل ۱۲ نویسه داشته باشد.");
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const key = await derivePasswordKey(password, salt, settings.passwordIterations);
      await api("auth/bootstrap", {
        method: "POST",
        body: {
          organizationName: form.elements.organizationName.value,
          displayName: form.elements.displayName.value,
          email: form.elements.email.value,
          bootstrapToken: form.elements.bootstrapToken.value,
          salt: toBase64Url(salt),
          derivedKey: toBase64Url(key),
        },
      });
      renderLogin();
      showToast("حساب مدیر ساخته شد؛ اکنون وارد شوید.");
    } catch (error) {
      showToast(error.message, true);
      button.disabled = false;
    }
  }

  async function activate(event, token) {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button");
    try {
      const password = form.elements.password.value;
      if (password.length < 12) throw new Error("رمز عبور باید حداقل ۱۲ نویسه داشته باشد.");
      if (password !== form.elements.confirm.value) throw new Error("تکرار رمز عبور یکسان نیست.");
      button.disabled = true;
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const key = await derivePasswordKey(password, salt, settings.passwordIterations);
      await api("auth/activate", { method: "POST", body: { token, salt: toBase64Url(salt), derivedKey: toBase64Url(key) } });
      history.replaceState(null, "", "/");
      renderLogin();
      showToast("حساب فعال شد؛ با ایمیل و رمز جدید وارد شوید.");
    } catch (error) {
      showToast(error.message, true);
      button.disabled = false;
    }
  }

  async function derivePasswordKey(password, salt, iterations) {
    const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, material, 256));
  }

  async function passwordProof(keyBytes, challengeId, nonce) {
    const key = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`hn-login-proof-v1:${challengeId}:${nonce}`)));
  }

  function toBase64Url(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  function fromBase64Url(value) {
    const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
    const binary = atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "="));
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]);
  }

  function showToast(message, error = false) {
    toastNode.textContent = message;
    toastNode.className = `show${error ? " error" : ""}`;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => { toastNode.className = ""; }, 4500);
  }

  async function initialize() {
    const token = new URLSearchParams(location.hash.replace(/^#/, "")).get("activate");
    if (token) return renderActivation(token);
    try {
      settings = await api("auth/status");
      if (settings.initialized) renderLogin(); else renderBootstrap();
    } catch (error) {
      card.innerHTML = `<h2>اتصال برقرار نشد</h2><p>ارتباط با سرور ممکن نیست. چند لحظه بعد صفحه را تازه‌سازی کنید.</p>`;
      showToast(error.message, true);
    }
  }

  initialize();
})();
