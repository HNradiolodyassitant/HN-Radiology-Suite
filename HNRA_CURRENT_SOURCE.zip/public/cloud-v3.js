(() => {
  "use strict";

  const REPORTS_KEY = "hnRadiologyReportsV1";
  const CLOUD_USER_KEY = "hnCloudUserIdV3";
  const PENDING_DELETES_KEY = "hnCloudPendingDeletesV3";
  const ROLE_LABELS = {
    owner: "مدیر سامانه",
    radiologist: "پزشک/رادیولوژیست",
    secretary: "منشی",
    viewer: "مشاهده‌گر",
  };
  const ROLE_DESCRIPTIONS = {
    owner: "دسترسی نامحدود به همه امکانات، مدیریت اعضا و بیماران، مشاهده همه گزارش‌ها و دریافت پشتیبان مرکز",
    radiologist: "ساخت، ویرایش و حذف گزارش‌های خودش و دسترسی به فهرست بیماران",
    secretary: "ثبت و جست‌وجوی بیمار بدون دسترسی به متن گزارش‌های پزشکی",
    viewer: "مشاهده گزارش‌ها بدون اجازه ساخت، ویرایش یا حذف",
  };
  const state = {
    me: null,
    organization: null,
    users: [],
    patients: [],
    reports: [],
    sessions: [],
    activationLink: null,
    initialLocalIds: new Set(),
    remoteClientIds: new Set(),
    cloudManagedLocalIds: new Set(),
    syncing: false,
    lastSync: null,
    activeTab: "account",
  };

  function readLocalReports() {
    try {
      const value = JSON.parse(localStorage.getItem(REPORTS_KEY) || "[]");
      return Array.isArray(value) ? value : [];
    } catch {
      return [];
    }
  }

  function writeLocalReports(items, source = "cloud") {
    localStorage.setItem(REPORTS_KEY, JSON.stringify(items));
    window.dispatchEvent(new CustomEvent("hn-reports-updated", { detail: { source } }));
  }

  function normalizeDigits(value) {
    const persian = "۰۱۲۳۴۵۶۷۸۹";
    const arabic = "٠١٢٣٤٥٦٧٨٩";
    return String(value ?? "")
      .replace(/[۰-۹]/g, (digit) => String(persian.indexOf(digit)))
      .replace(/[٠-٩]/g, (digit) => String(arabic.indexOf(digit)));
  }

  function readPendingDeletes() {
    try {
      const value = JSON.parse(localStorage.getItem(PENDING_DELETES_KEY) || "[]");
      return Array.isArray(value) ? value.filter((id) => typeof id === "string" && id) : [];
    } catch {
      return [];
    }
  }

  function writePendingDeletes(ids) {
    localStorage.setItem(PENDING_DELETES_KEY, JSON.stringify([...new Set(ids)]));
  }

  async function api(path, options = {}) {
    const init = { credentials: "same-origin", ...options };
    init.headers = { "x-hn-request": "1", ...(init.headers || {}) };
    if (init.body && typeof init.body !== "string") {
      init.headers = { "content-type": "application/json", ...(init.headers || {}) };
      init.body = JSON.stringify(init.body);
    }
    const response = await fetch(`/api/${path}`, init);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || `خطای ${response.status}`);
      error.status = response.status;
      error.code = data.code;
      throw error;
    }
    return data;
  }

  function createShell() {
    const root = document.createElement("div");
    root.id = "hn-cloud-root";
    root.innerHTML = `
      <style>
        #hn-cloud-button{left:auto!important;right:18px!important}
        #hn-emergency-backup{left:auto!important;right:20px!important}
        @media(max-width:650px){
          #hn-cloud-overlay{background:#071b2bf0;align-items:stretch}
          #hn-cloud-button{left:auto!important;right:12px!important;bottom:calc(12px + env(safe-area-inset-bottom))!important}
          #hn-cloud-panel{width:100vw;max-width:none;height:100dvh;box-shadow:none;animation:none}
          .hn-cloud-header{padding:calc(14px + env(safe-area-inset-top)) 15px 14px;position:sticky;top:0;z-index:2}
          .hn-cloud-header strong{font-size:18px}.hn-cloud-header small{font-size:11px}
          #hn-cloud-tabs{padding:0 7px;overflow-x:auto;scrollbar-width:none;position:sticky;top:0;z-index:1}
          #hn-cloud-tabs::-webkit-scrollbar{display:none}#hn-cloud-tabs button{padding:13px 12px;white-space:nowrap;flex:1}
          #hn-cloud-content{padding:10px 10px calc(22px + env(safe-area-inset-bottom))}
          .hn-cloud-card,.hn-cloud-form{border-radius:14px;padding:14px}.hn-cloud-profile{border-radius:14px;padding:12px}
          .hn-cloud-actions{display:grid;grid-template-columns:1fr}.hn-cloud-actions button,.hn-cloud-form>button{min-height:44px;width:100%}
          .hn-copy-line{display:grid;grid-template-columns:1fr}.hn-copy-line button{min-height:42px}
          .hn-cloud-list-head{align-items:stretch;flex-direction:column}#hn-patient-search{max-width:none;height:44px}
          .hn-cloud-row{grid-template-columns:1fr;gap:7px}.hn-user-actions{display:grid!important;grid-template-columns:1fr 1fr}
          .hn-cloud-form input,.hn-cloud-form select{height:44px;font-size:16px}
          .hn-reports-page{padding:12px!important;padding-top:calc(12px + env(safe-area-inset-top))!important;padding-bottom:calc(76px + env(safe-area-inset-bottom))!important}
          .hn-reports-page h1{font-size:25px;margin-block:18px 10px}.hn-reports-toolbar{display:grid!important;grid-template-columns:1fr 1fr;align-items:stretch!important}
          .hn-reports-toolbar button{min-height:44px}.hn-reports-toolbar span{grid-column:1/-1}.hn-report-card{padding:13px!important;border-radius:12px!important}
          .hn-report-actions{display:grid!important;grid-template-columns:1fr 1fr}.hn-report-actions button{min-height:43px;padding:8px 6px}
          .hn-report-text{font-size:14px;line-height:1.9!important;max-height:52vh;overflow:auto}.hn-report-editor{font-size:16px!important;min-height:42vh}
          #hn-cloud-toast{right:10px;left:10px;bottom:calc(10px + env(safe-area-inset-bottom));max-width:none;text-align:center}
        }
      </style>
      <button id="hn-cloud-button" type="button" title="حساب و آرشیو ابری">
        <span class="hn-cloud-dot"></span>
        <span>حساب و آرشیو</span>
      </button>
      <a id="hn-emergency-backup" href="https://hnradiolodyassitant.github.io/HN-Radiology-Suite/" target="_blank" rel="noopener noreferrer" title="نسخه پشتیبان اضطراری">نسخه پشتیبان</a>
      <div id="hn-cloud-overlay" aria-hidden="true">
        <section id="hn-cloud-panel" role="dialog" aria-modal="true" aria-label="حساب و آرشیو ابری">
          <header class="hn-cloud-header">
            <div>
              <strong>HN Cloud</strong>
              <small>حساب، بیماران و همگام‌سازی</small>
            </div>
            <button id="hn-cloud-close" type="button" aria-label="بستن">×</button>
          </header>
          <nav id="hn-cloud-tabs"></nav>
          <main id="hn-cloud-content"><div class="hn-cloud-loading">در حال اتصال امن…</div></main>
        </section>
      </div>
      <div id="hn-cloud-toast" role="status" aria-live="polite"></div>`;
    document.body.appendChild(root);

    root.querySelector("#hn-cloud-button").addEventListener("click", openPanel);
    root.querySelector("#hn-cloud-close").addEventListener("click", closePanel);
    root.querySelector("#hn-cloud-overlay").addEventListener("click", (event) => {
      if (event.target.id === "hn-cloud-overlay") closePanel();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closePanel();
    });
  }

  function openPanel() {
    const overlay = document.getElementById("hn-cloud-overlay");
    overlay.classList.add("open");
    overlay.setAttribute("aria-hidden", "false");
    render();
  }

  function closePanel() {
    const overlay = document.getElementById("hn-cloud-overlay");
    overlay?.classList.remove("open");
    overlay?.setAttribute("aria-hidden", "true");
  }

  function render() {
    renderTabs();
    if (!state.me) return renderUnavailable();
    if (state.activeTab === "patients") return renderPatients();
    if (state.activeTab === "users" && state.me.role === "owner") return renderUsers();
    return renderAccount();
  }

  function renderTabs() {
    const tabs = document.getElementById("hn-cloud-tabs");
    if (!tabs) return;
    const items = [
      ["account", "حساب من"],
      ["patients", "بیماران"],
      ...(state.me?.role === "owner" ? [["users", "اعضای سامانه"]] : []),
    ];
    tabs.innerHTML = items.map(([id, label]) =>
      `<button type="button" data-tab="${id}" class="${state.activeTab === id ? "active" : ""}">${label}</button>`,
    ).join("");
    tabs.querySelectorAll("[data-tab]").forEach((button) => button.addEventListener("click", () => {
      state.activeTab = button.dataset.tab;
      render();
      if (state.activeTab === "patients") refreshPatients();
      if (state.activeTab === "users") refreshUsers();
    }));
  }

  function renderUnavailable() {
    const content = document.getElementById("hn-cloud-content");
    content.innerHTML = `
      <div class="hn-cloud-empty">
        <strong>نشست ورود در دسترس نیست</strong>
        <p>ممکن است نشست این دستگاه منقضی شده باشد. صفحه را تازه‌سازی کنید و دوباره وارد شوید.</p>
        <button type="button" class="primary" onclick="location.reload()">ورود دوباره</button>
      </div>`;
  }

  function renderAccount() {
    const localCount = readLocalReports().length;
    const canWriteReports = ["owner", "radiologist"].includes(state.me.role);
    const content = document.getElementById("hn-cloud-content");
    content.innerHTML = `
      <div class="hn-cloud-profile">
        <div class="hn-cloud-avatar">${escapeHtml((state.me.displayName || state.me.email).slice(0, 1).toUpperCase())}</div>
        <div><strong>${escapeHtml(state.me.displayName)}</strong><small>${escapeHtml(state.me.email)}</small></div>
        <span class="hn-cloud-role">${ROLE_LABELS[state.me.role] || state.me.role}</span>
      </div>
      <div class="hn-cloud-card compact"><h3>دسترسی این حساب</h3><p>${escapeHtml(ROLE_DESCRIPTIONS[state.me.role] || "")}</p></div>
      <div class="hn-subscription ${state.organization?.subscriptionActive ? "active" : "inactive"}">
        <strong>${state.organization?.unlimitedAccess ? "دسترسی نامحدود مدیر" : state.organization?.subscriptionActive ? "اشتراک فعال" : "اشتراک نیازمند تمدید"}</strong>
        <span>${state.organization?.unlimitedAccess ? "بدون قفل زمانی یا محدودیت قابلیت" : state.organization?.subscriptionExpiresAt ? `اعتبار تا ${formatDate(state.organization.subscriptionExpiresAt)}` : "بدون تاریخ انقضا"}</span>
      </div>
      <div class="hn-cloud-stats">
        <div><strong>${state.reports.length}</strong><span>گزارش ابری</span></div>
        <div><strong>${state.patients.length}</strong><span>بیمار</span></div>
        <div><strong>${localCount}</strong><span>گزارش این دستگاه</span></div>
      </div>
      <div class="hn-cloud-card">
        <h3>همگام‌سازی بین دستگاه‌ها</h3>
        <p>گزارش‌های ابری روی گوشی و لپ‌تاپ با همین حساب در دسترس‌اند. گزارش‌های جدید این دستگاه خودکار همگام می‌شوند.</p>
        <div class="hn-cloud-actions">
          <button id="hn-sync-now" class="primary" type="button">همگام‌سازی اکنون</button>
          ${canWriteReports ? `<button id="hn-import-local" type="button">انتقال آرشیو قدیمی این دستگاه</button>` : ""}
        </div>
        <small class="hn-cloud-note">${state.lastSync ? `آخرین همگام‌سازی: ${formatDate(state.lastSync)}` : "هنوز همگام‌سازی انجام نشده است."}</small>
      </div>
      <div class="hn-cloud-card compact">
        <h3>نشست ورود</h3>
        <p>این حساب می‌تواند هم‌زمان روی گوشی و لپ‌تاپ فعال باشد. هر نشست ۱۲ ساعت اعتبار دارد.</p>
        <div id="hn-session-list">${sessionRows(state.sessions)}</div>
        <div class="hn-cloud-actions top-gap">
          <button id="hn-logout" type="button">خروج از این دستگاه</button>
          <button id="hn-logout-all" type="button">خروج از همه دستگاه‌ها</button>
        </div>
      </div>
      ${state.me.role === "owner" ? `<div class="hn-cloud-card compact"><h3>پشتیبان مرکز</h3><p>یک فایل JSON شامل اعضا، بیماران، گزارش‌ها و تاریخچهٔ ویرایش دریافت کنید و در محل امن نگه دارید.</p><button id="hn-download-backup" type="button">دریافت فایل پشتیبان</button></div>` : ""}
      <form id="hn-password-form" class="hn-cloud-form">
        <h3>تغییر رمز عبور</h3>
        <div class="hn-cloud-grid three">
          <label>رمز فعلی<input name="currentPassword" type="password" autocomplete="current-password" minlength="12" required></label>
          <label>رمز جدید<input name="newPassword" type="password" autocomplete="new-password" minlength="12" maxlength="128" required></label>
          <label>تکرار رمز جدید<input name="confirmPassword" type="password" autocomplete="new-password" minlength="12" maxlength="128" required></label>
        </div>
        <button class="primary" type="submit">تغییر رمز</button>
      </form>`;
    content.querySelector("#hn-sync-now")?.addEventListener("click", () => syncAll(false));
    content.querySelector("#hn-import-local")?.addEventListener("click", importExistingLocal);
    content.querySelector("#hn-logout")?.addEventListener("click", () => logout(false));
    content.querySelector("#hn-logout-all")?.addEventListener("click", () => logout(true));
    content.querySelector("#hn-download-backup")?.addEventListener("click", downloadBackup);
    content.querySelector("#hn-password-form")?.addEventListener("submit", changePassword);
    content.querySelectorAll("[data-revoke-session]").forEach((button) => button.addEventListener("click", () => revokeSession(button.dataset.revokeSession)));
  }

  function sessionRows(sessions) {
    if (!sessions.length) return `<div class="hn-cloud-empty small">نشست فعالی پیدا نشد.</div>`;
    return `<div class="hn-cloud-table">${sessions.map((session) => `
      <div class="hn-cloud-row session">
        <div><strong>${escapeHtml(session.deviceLabel)}</strong><small>${session.current ? "همین دستگاه" : `آخرین فعالیت: ${formatDate(session.lastSeenAt)}`}</small></div>
        <div><span>انقضا: ${formatDate(session.expiresAt)}</span></div>
        ${session.current ? `<span class="hn-cloud-owner">فعال</span>` : `<button type="button" data-revoke-session="${escapeHtml(session.id)}">قطع دسترسی</button>`}
      </div>`).join("")}</div>`;
  }

  function renderPatients() {
    const canEdit = ["owner", "radiologist", "secretary"].includes(state.me.role);
    const content = document.getElementById("hn-cloud-content");
    content.innerHTML = `
      ${canEdit ? `
      <form id="hn-patient-form" class="hn-cloud-form">
        <h3>ثبت بیمار</h3>
        <div class="hn-cloud-grid">
          <label>شناسه شش‌رقمی<input name="patientCode" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required></label>
          <label>نام و نام خانوادگی<input name="fullName" maxlength="160"></label>
          <label>تاریخ تولد<input name="birthDate" placeholder="مثلاً ۱۳۶۵/۰۴/۱۲" maxlength="20"></label>
          <label>جنسیت<select name="sex"><option value="">ثبت نشده</option><option value="female">زن</option><option value="male">مرد</option><option value="other">سایر</option></select></label>
          <label>تلفن<input name="phone" inputmode="tel" maxlength="40"></label>
          <label>مرکز/کلینیک<input name="clinic" maxlength="160"></label>
        </div>
        <button class="primary" type="submit">ذخیره بیمار</button>
      </form>` : ""}
      <div class="hn-cloud-card">
        <div class="hn-cloud-list-head">
          <h3>آرشیو بیماران</h3>
          <input id="hn-patient-search" type="search" placeholder="جست‌وجوی نام یا شناسه…">
        </div>
        <div id="hn-patient-list">${patientRows(state.patients)}</div>
      </div>`;

    content.querySelector("#hn-patient-form")?.addEventListener("submit", submitPatient);
    content.querySelector("#hn-patient-form [name=patientCode]")?.addEventListener("input", (event) => {
      event.target.value = normalizeDigits(event.target.value).replace(/\D/g, "").slice(0, 6);
    });
    let timer;
    content.querySelector("#hn-patient-search")?.addEventListener("input", (event) => {
      clearTimeout(timer);
      timer = setTimeout(() => refreshPatients(event.target.value), 250);
    });
  }

  function patientRows(patients) {
    if (!patients.length) return `<div class="hn-cloud-empty small">هنوز بیماری ثبت نشده است.</div>`;
    return `<div class="hn-cloud-table">${patients.map((patient) => `
      <div class="hn-cloud-row">
        <div><strong>${escapeHtml(patient.fullName || "بدون نام")}</strong><small>شناسه: ${escapeHtml(patient.patientCode)}</small></div>
        <div><span>${escapeHtml(patient.clinic || "—")}</span><small>${formatDate(patient.updatedAt)}</small></div>
      </div>`).join("")}</div>`;
  }

  async function submitPatient(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    data.patientCode = normalizeDigits(data.patientCode).replace(/\D/g, "").slice(0, 6);
    try {
      await api("patients", { method: "POST", body: data });
      form.reset();
      toast("بیمار در آرشیو ابری ذخیره شد.", "ok");
      await refreshPatients();
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function refreshPatients(query = "") {
    try {
      const data = await api(`patients?q=${encodeURIComponent(query)}&limit=200`);
      state.patients = data.patients;
      const list = document.getElementById("hn-patient-list");
      if (list) list.innerHTML = patientRows(state.patients);
    } catch (error) {
      toast(error.message, "error");
    }
  }

  function renderUsers() {
    const content = document.getElementById("hn-cloud-content");
    content.innerHTML = `
      ${state.activationLink ? `
      <div class="hn-cloud-card hn-invite-card">
        <h3>لینک فعال‌سازی عضو</h3>
        <p>این لینک فقط یک‌بار نمایش داده می‌شود و تا ${formatDate(state.activationLink.expiresAt)} معتبر است.</p>
        <div class="hn-copy-line"><input id="hn-activation-url" value="${escapeHtml(state.activationLink.url)}" readonly dir="ltr"><button id="hn-copy-activation" type="button">کپی لینک</button></div>
      </div>` : ""}
      <form id="hn-user-form" class="hn-cloud-form">
        <h3>افزودن عضو</h3>
        <div class="hn-cloud-grid three">
          <label>نام نمایشی<input name="displayName" maxlength="120" required></label>
          <label>ایمیل ورود<input name="email" type="email" maxlength="254" required></label>
          <label>نقش<select name="role"><option value="radiologist">پزشک/رادیولوژیست</option><option value="secretary">منشی</option><option value="viewer">مشاهده‌گر</option></select></label>
        </div>
        <button class="primary" type="submit">افزودن عضو</button>
        <small class="hn-cloud-note">پزشک فقط گزارش‌های خودش را مدیریت می‌کند؛ منشی فقط پرونده بیمار را ثبت می‌کند؛ مدیر به مدیریت کل مرکز دسترسی دارد.</small>
      </form>
      <div class="hn-cloud-card">
        <h3>اعضای سامانه</h3>
        <div id="hn-user-list">${userRows(state.users)}</div>
      </div>`;
    content.querySelector("#hn-user-form")?.addEventListener("submit", submitUser);
    content.querySelectorAll("[data-toggle-user]").forEach((button) => button.addEventListener("click", () => toggleUser(button)));
    content.querySelectorAll("[data-invite-user]").forEach((button) => button.addEventListener("click", () => resetInvite(button.dataset.inviteUser)));
    content.querySelector("#hn-copy-activation")?.addEventListener("click", copyActivationLink);
  }

  function userRows(users) {
    if (!users.length) return `<div class="hn-cloud-empty small">عضوی پیدا نشد.</div>`;
    return `<div class="hn-cloud-table">${users.map((user) => `
      <div class="hn-cloud-row user ${user.active ? "" : "inactive"}">
        <div><strong>${escapeHtml(user.displayName)}</strong><small>${escapeHtml(user.email)}</small></div>
        <div><span>${ROLE_LABELS[user.role] || user.role}</span><small>${user.active ? (user.passwordSet ? "فعال" : "در انتظار فعال‌سازی") : "غیرفعال"}</small></div>
        ${user.role === "owner" ? `<span class="hn-cloud-owner">مدیر اصلی</span>` : `<div class="hn-user-actions"><button type="button" data-invite-user="${escapeHtml(user.id)}">لینک جدید</button><button type="button" data-toggle-user="${escapeHtml(user.id)}" data-active="${user.active ? "1" : "0"}">${user.active ? "غیرفعال" : "فعال"}</button></div>`}
      </div>`).join("")}</div>`;
  }

  async function submitUser(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    try {
      const result = await api("users", { method: "POST", body: data });
      form.reset();
      state.activationLink = { url: result.activationUrl, expiresAt: result.activationExpiresAt };
      toast("عضو اضافه شد؛ لینک فعال‌سازی را برای خودش بفرستید.", "ok");
      await refreshUsers();
      renderUsers();
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function toggleUser(button) {
    try {
      await api(`users/${button.dataset.toggleUser}`, {
        method: "PATCH",
        body: { active: button.dataset.active !== "1" },
      });
      toast("وضعیت عضو به‌روزرسانی شد.", "ok");
      await refreshUsers();
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function resetInvite(userId) {
    if (!window.confirm("رمز فعلی این عضو و همه نشست‌های فعال او لغو شود و لینک تازه ساخته شود؟")) return;
    try {
      const result = await api(`users/${userId}/invite`, { method: "POST", body: {} });
      state.activationLink = { url: result.activationUrl, expiresAt: result.activationExpiresAt };
      await refreshUsers();
      renderUsers();
      toast("لینک فعال‌سازی جدید ساخته شد.", "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function copyActivationLink() {
    const input = document.getElementById("hn-activation-url");
    if (!input) return;
    try { await navigator.clipboard.writeText(input.value); }
    catch { input.select(); document.execCommand("copy"); }
    toast("لینک فعال‌سازی کپی شد.", "ok");
  }

  async function refreshUsers() {
    if (state.me?.role !== "owner") return;
    try {
      state.users = (await api("users")).users;
      const list = document.getElementById("hn-user-list");
      if (list) {
        list.innerHTML = userRows(state.users);
        list.querySelectorAll("[data-toggle-user]").forEach((button) => button.addEventListener("click", () => toggleUser(button)));
        list.querySelectorAll("[data-invite-user]").forEach((button) => button.addEventListener("click", () => resetInvite(button.dataset.inviteUser)));
      }
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function refreshSessions() {
    if (!state.me) return;
    try {
      state.sessions = (await api("auth/sessions")).sessions;
      const list = document.getElementById("hn-session-list");
      if (list) {
        list.innerHTML = sessionRows(state.sessions);
        list.querySelectorAll("[data-revoke-session]").forEach((button) => button.addEventListener("click", () => revokeSession(button.dataset.revokeSession)));
      }
    } catch (error) {
      if (error.status === 401) location.reload();
      else toast(error.message, "error");
    }
  }

  async function revokeSession(sessionId) {
    try {
      await api(`auth/sessions/${sessionId}`, { method: "DELETE" });
      await refreshSessions();
      toast("دسترسی آن دستگاه قطع شد.", "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  }

  async function logout(allDevices) {
    if (allDevices && !window.confirm("از حساب روی همه گوشی‌ها و رایانه‌ها خارج شوید؟")) return;
    try { await api(allDevices ? "auth/logout-all" : "auth/logout", { method: "POST", body: {} }); }
    finally {
      localStorage.removeItem(REPORTS_KEY);
      localStorage.removeItem(CLOUD_USER_KEY);
      location.reload();
    }
  }

  async function changePassword(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const currentPassword = form.elements.currentPassword.value;
    const newPassword = form.elements.newPassword.value;
    if (newPassword.length < 12) return toast("رمز جدید باید حداقل ۱۲ نویسه داشته باشد.", "error");
    if (newPassword !== form.elements.confirmPassword.value) return toast("تکرار رمز جدید یکسان نیست.", "error");
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    try {
      const challenge = await api("auth/challenge", { method: "POST", body: { email: state.me.email } });
      const currentKey = await derivePasswordKey(currentPassword, fromBase64Url(challenge.salt), challenge.passwordIterations);
      const proof = await passwordProof(currentKey, challenge.challengeId, challenge.nonce);
      const newSalt = crypto.getRandomValues(new Uint8Array(16));
      const newKey = await derivePasswordKey(newPassword, newSalt, challenge.passwordIterations);
      await api("auth/password/change", {
        method: "POST",
        body: { challengeId: challenge.challengeId, proof: toBase64Url(proof), salt: toBase64Url(newSalt), derivedKey: toBase64Url(newKey) },
      });
      form.reset();
      toast("رمز تغییر کرد و نشست دستگاه‌های دیگر بسته شد.", "ok");
      await refreshSessions();
    } catch (error) {
      toast(error.message, "error");
    } finally {
      button.disabled = false;
    }
  }

  async function downloadBackup(event) {
    const button = event.currentTarget;
    button.disabled = true;
    try {
      const response = await fetch("/api/admin/export", { credentials: "same-origin", headers: { "x-hn-request": "1" } });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || "دریافت فایل پشتیبان ممکن نشد.");
      }
      const blobUrl = URL.createObjectURL(await response.blob());
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `hn-radiology-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(blobUrl);
      toast("فایل پشتیبان دریافت شد؛ آن را در محل امن نگه دارید.", "ok");
    } catch (error) {
      toast(error.message, "error");
    } finally {
      button.disabled = false;
    }
  }

  async function derivePasswordKey(password, salt, iterations) {
    const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, material, 256));
  }

  async function passwordProof(keyBytes, challengeId, nonce) {
    const key = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`hn-login-proof-v1:${challengeId}:${nonce}`)));
  }

  function toBase64Url(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  function fromBase64Url(value) {
    const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
    const binary = atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "="));
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  }

  async function pullCloudReports() {
    if (!["owner", "radiologist", "viewer"].includes(state.me?.role)) return;
    const data = await api("reports?limit=250");
    state.reports = data.reports;
    state.remoteClientIds = new Set(data.reports.map((item) => item.clientId).filter(Boolean));
    const remoteIds = new Set(data.reports.map((item) => item.id));
    const current = readLocalReports();
    const byId = new Map();
    for (const item of current) {
      const isCloudBacked = Boolean(item?.cloudId) || String(item?.id || "").startsWith("cloud_");
      if (!isCloudBacked || (item.cloudId && remoteIds.has(item.cloudId))) byId.set(item.id, item);
    }
    const nextCloudManagedIds = new Set();
    for (const report of data.reports) {
      const localId = report.clientId || `cloud_${report.id}`;
      nextCloudManagedIds.add(localId);
      const existing = byId.get(localId) || current.find((item) => item?.cloudId === report.id) || {};
      byId.set(localId, {
        ...existing,
        id: localId,
        cloudId: report.id,
        patientId: report.patientCode,
        patientName: report.patientName,
        examTitle: report.examTitle,
        fullReport: report.reportText,
        reportText: report.reportText,
        createdAt: report.createdAt,
        updatedAt: report.updatedAt,
        cloudUpdatedAt: report.updatedAt,
        syncState: "synced",
      });
      state.initialLocalIds.add(localId);
    }
    state.cloudManagedLocalIds = nextCloudManagedIds;
    const merged = [...byId.values()].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    writeLocalReports(merged, "cloud");
  }

  async function pushReports(items) {
    if (!["owner", "radiologist"].includes(state.me?.role)) return { pushed: 0, skipped: items.length };
    let pushed = 0;
    let skipped = 0;
    const local = readLocalReports();
    const updates = new Map();
    for (const item of items) {
      const reportText = item?.reportText || item?.fullReport || "";
      const patientCode = normalizeDigits(item?.patientId).trim();
      if (!item?.id || !/^\d{6}$/.test(patientCode) || !reportText) {
        skipped += 1;
        continue;
      }
      try {
        const result = item.cloudId
          ? await api(`reports/${item.cloudId}`, {
              method: "PATCH",
              body: { examTitle: item.examTitle || "گزارش سونوگرافی", reportText, status: "final" },
            })
          : await api("reports", {
              method: "POST",
              body: {
                clientId: item.id,
                patientCode,
                patientName: item.patientName || "",
                examTitle: item.examTitle || "گزارش سونوگرافی",
                reportText,
                status: "final",
                createdAt: item.createdAt,
              },
            });
        state.remoteClientIds.add(item.id);
        if (result.report) state.reports.unshift(result.report);
        if (result.report) updates.set(item.id, {
          ...item,
          cloudId: result.report.id,
          patientId: result.report.patientCode,
          patientName: result.report.patientName || item.patientName || "",
          fullReport: result.report.reportText,
          reportText: result.report.reportText,
          updatedAt: result.report.updatedAt,
          cloudUpdatedAt: result.report.updatedAt,
          syncState: "synced",
        });
        pushed += 1;
      } catch (error) {
        if (error.status === 403) return { pushed, skipped: items.length - pushed };
        throw error;
      }
    }
    if (updates.size) writeLocalReports(local.map((item) => updates.get(item.id) || item), "cloud");
    return { pushed, skipped };
  }

  async function flushPendingDeletes() {
    const pending = readPendingDeletes();
    if (!pending.length || !["owner", "radiologist"].includes(state.me?.role)) return;
    const remaining = [];
    for (const reportId of pending) {
      try { await api(`reports/${reportId}`, { method: "DELETE" }); }
      catch (error) {
        if (error.status !== 404) remaining.push(reportId);
      }
    }
    writePendingDeletes(remaining);
  }

  async function deleteCloudReport(item) {
    if (!item?.cloudId) return;
    if (!["owner", "radiologist"].includes(state.me?.role)) throw new Error("این حساب اجازه حذف گزارش را ندارد.");
    try {
      await api(`reports/${item.cloudId}`, { method: "DELETE" });
    } catch (error) {
      if (error.status === 403) throw error;
      writePendingDeletes([...readPendingDeletes(), item.cloudId]);
      toast("حذف روی این دستگاه انجام شد و در اولین اتصال از ابر هم حذف می‌شود.", "ok");
    }
    state.reports = state.reports.filter((report) => report.id !== item.cloudId);
  }

  async function syncAll(includeExisting = false) {
    if (state.syncing || !state.me) return;
    state.syncing = true;
    setButtonState("syncing");
    try {
      await flushPendingDeletes();
      const local = readLocalReports();
      const candidates = local.filter((item) => item?.syncState === "dirty" || (!item?.cloudId && (includeExisting || !state.initialLocalIds.has(item.id))));
      const result = await pushReports(candidates);
      await pullCloudReports();
      await refreshPatients();
      state.lastSync = new Date().toISOString();
      if (includeExisting) toast(`${result.pushed} گزارش به آرشیو ابری منتقل شد.`, "ok");
      setButtonState("ready");
      if (document.getElementById("hn-cloud-overlay")?.classList.contains("open")) render();
    } catch (error) {
      setButtonState("error");
      toast(error.message, "error");
    } finally {
      state.syncing = false;
    }
  }

  function importExistingLocal() {
    const count = readLocalReports().filter((item) => !item?.cloudId && !state.remoteClientIds.has(item.id)).length;
    if (!count) return toast("گزارش انتقال‌نیافته‌ای روی این دستگاه وجود ندارد.", "ok");
    const confirmed = window.confirm(`آیا ${count} گزارش موجود روی این دستگاه به آرشیو ابری منتقل شود؟`);
    if (confirmed) syncAll(true);
  }

  function setButtonState(mode) {
    const button = document.getElementById("hn-cloud-button");
    if (!button) return;
    button.dataset.state = mode;
    button.title = mode === "error" ? "اتصال ابری نیاز به بررسی دارد" : mode === "syncing" ? "در حال همگام‌سازی" : "حساب و آرشیو ابری";
  }

  function toast(message, kind = "ok") {
    const element = document.getElementById("hn-cloud-toast");
    if (!element) return;
    element.textContent = message;
    element.className = `show ${kind}`;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { element.className = ""; }, 4000);
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
    })[character]);
  }

  function formatDate(value) {
    if (!value) return "—";
    try { return new Intl.DateTimeFormat("fa-IR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value)); }
    catch { return String(value); }
  }

  async function initialize() {
    createShell();
    try {
      const data = await api("me");
      state.me = data.user;
      state.organization = data.organization;
      const previousUser = localStorage.getItem(CLOUD_USER_KEY);
      if (previousUser && previousUser !== state.me.id) {
        localStorage.removeItem(REPORTS_KEY);
        localStorage.removeItem(PENDING_DELETES_KEY);
      }
      localStorage.setItem(CLOUD_USER_KEY, state.me.id);
      const existing = readLocalReports();
      state.initialLocalIds = new Set(existing.map((item) => item.id).filter(Boolean));
      document.querySelectorAll("button, a").forEach((element) => {
        if ((element.textContent || "").trim() === "ورود پزشک/منشی") {
          element.textContent = state.me.displayName || "حساب من";
          element.addEventListener("click", (event) => { event.preventDefault(); openPanel(); });
        }
      });
      setButtonState("ready");
      await Promise.all([
        refreshPatients(),
        state.me.role === "owner" ? refreshUsers() : Promise.resolve(),
        ["owner", "radiologist", "viewer"].includes(state.me.role) ? pullCloudReports() : Promise.resolve(),
        refreshSessions(),
      ]);
      state.lastSync = new Date().toISOString();
      render();
      let localSyncTimer;
      window.addEventListener("hn-reports-updated", (event) => {
        if (event.detail?.source === "cloud") return;
        clearTimeout(localSyncTimer);
        localSyncTimer = setTimeout(() => syncAll(false), 250);
      });
      setInterval(() => syncAll(false), 15000);
    } catch (error) {
      setButtonState("error");
      render();
      if (error.status === 401) location.reload();
      else if (error.status !== 403) toast(error.message, "error");
    }
  }

  window.HNCloud = {
    deleteReport: deleteCloudReport,
    syncNow: () => syncAll(false),
    normalizePatientId: (value) => normalizeDigits(value).replace(/\D/g, "").slice(0, 6),
    getReportDoctors: () => [...new Set([state.me, ...state.users]
      .filter((user) => user && user.active !== false && ["owner", "radiologist"].includes(user.role))
      .map((user) => String(user.displayName || "").trim())
      .filter(Boolean))],
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialize, { once: true });
  else initialize();
})();
